#!/usr/bin/env python
"""
Direct test of Ollama API for role-based thought generation without DSPy.
This provides a fallback approach for our experiment.
"""

import json
import logging
import requests
import sys
from pathlib import Path

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger("direct_ollama_test")

# Add the project root to Python path for importing project modules
sys.path.append(str(Path(__file__).parent.parent))

# Import relevant project components if available
try:
    from src.agents.core.roles import ROLE_FACILITATOR, ROLE_INNOVATOR, ROLE_ANALYZER, ROLE_DESCRIPTIONS
except ImportError:
    # Fallback values
    ROLE_FACILITATOR = "Facilitator"
    ROLE_INNOVATOR = "Innovator"
    ROLE_ANALYZER = "Analyzer"
    ROLE_DESCRIPTIONS = {
        "Facilitator": "Facilitator: Your aim is to ensure smooth collaboration, encourage participation, and help synthesize diverse viewpoints.",
        "Innovator": "Innovator: Your aim is to generate novel ideas, propose creative technical solutions, and explore unconventional approaches.",
        "Analyzer": "Analyzer: Your aim is to critically evaluate proposals, identify potential flaws, and ensure solutions are robust."
    }

# Constants
OLLAMA_API_URL = "http://localhost:11434/api/generate"
OLLAMA_MODEL = "mistral:latest"

def create_role_based_prompt(role, role_description, situation):
    """Create a prompt for role-based thought generation."""
    return f"""
You are acting as an AI assistant that generates thoughts for an agent with a specific role.

ROLE: {role}
ROLE DESCRIPTION: {role_description}
CURRENT SITUATION: {situation}

Your task is to generate a thought process that strongly reflects the given agent role and the current situation.
The thought should clearly demonstrate thinking that is consistent with the role description.

Begin the thought with "As a/an [ROLE]," and be sure that the entire thought process reflects how someone in this role would think about the situation.

Thought Process:
"""

def generate_thought_with_ollama(role, situation):
    """Generate a thought using direct Ollama API call."""
    # Get role description
    role_description = ROLE_DESCRIPTIONS.get(role, f"{role}: Act according to this role's responsibilities.")
    
    # Create the prompt
    prompt = create_role_based_prompt(role, role_description, situation)
    
    # Prepare the API request
    payload = {
        "model": OLLAMA_MODEL,
        "prompt": prompt,
        "stream": False,  # Get complete response at once
        "options": {
            "temperature": 0.7
        }
    }
    
    try:
        # Make the API request
        logger.info(f"Sending request to Ollama API for role: {role}")
        response = requests.post(OLLAMA_API_URL, json=payload)
        response.raise_for_status()
        
        # Process the response
        result = response.json()
        generated_text = result.get("response", "")
        
        logger.info(f"Generated thought for role {role} ({len(generated_text)} chars)")
        return generated_text
    
    except Exception as e:
        logger.error(f"Error generating thought: {e}")
        return f"Error: {str(e)}"

def evaluate_role_adherence(role, generated_thought):
    """
    Basic evaluation of whether the generated thought adheres to the expected role.
    """
    thought = generated_thought.lower()
    role = role.lower()
    
    # Define role-specific keywords to look for
    role_keywords = {
        "innovator": ["new", "novel", "creative", "idea", "innovative", "unconventional"],
        "analyzer": ["evaluate", "analysis", "risk", "consider", "examine", "critical", "flaw"],
        "facilitator": ["summarize", "consensus", "collaboration", "discussion", "synthesis", "clarify"]
    }
    
    # Count how many role-appropriate keywords are present
    keywords = role_keywords.get(role, [])
    matches = sum(1 for keyword in keywords if keyword in thought)
    
    # Simple scoring
    score = min(1.0, matches / 4)  # Normalize to 0-1 range
    
    # Check for role phrase
    role_phrase = f"as a {role}"
    alt_role_phrase = f"as an {role}"
    has_role_phrase = role_phrase in thought or alt_role_phrase in thought
    
    if has_role_phrase:
        score = min(1.0, score + 0.3)  # Boost score if explicit role mention exists
    
    logger.info(f"Role adherence score for {role}: {score:.2f}")
    logger.info(f"  - Found {matches} keywords")
    logger.info(f"  - Has role phrase: {has_role_phrase}")
    
    return {
        "role": role,
        "score": score,
        "passes_threshold": score >= 0.5,
        "keyword_matches": matches,
        "has_role_phrase": has_role_phrase
    }

def run_test_scenarios():
    """Run test scenarios for different roles and situations."""
    scenarios = [
        {
            "role": ROLE_INNOVATOR,
            "situation": "The team is discussing a decentralized protocol design but seems stuck on conventional approaches."
        },
        {
            "role": ROLE_ANALYZER,
            "situation": "A new communication protocol has been proposed that claims to be both efficient and secure."
        },
        {
            "role": ROLE_FACILITATOR,
            "situation": "Two agents are presenting conflicting approaches to resource allocation in the protocol."
        }
    ]
    
    results = []
    
    for scenario in scenarios:
        role = scenario["role"]
        situation = scenario["situation"]
        
        logger.info(f"\n--- Testing {role} role ---")
        logger.info(f"Situation: {situation}")
        
        # Generate thought
        generated_thought = generate_thought_with_ollama(role, situation)
        
        # Evaluate the thought
        evaluation = evaluate_role_adherence(role, generated_thought)
        
        # Store result
        result = {
            "role": role,
            "situation": situation,
            "generated_thought": generated_thought,
            "evaluation": evaluation
        }
        results.append(result)
        
        logger.info(f"Result for {role}: {'PASS' if evaluation['passes_threshold'] else 'FAIL'}\n")
    
    return results

def create_report(results):
    """Create a report of the test results."""
    output_dir = Path(__file__).parent
    
    # Save raw results
    with open(output_dir / "direct_ollama_results.json", "w") as f:
        json.dump(results, f, indent=2)
    
    # Calculate success rate
    success_count = sum(1 for r in results if r["evaluation"]["passes_threshold"])
    success_rate = success_count / len(results) if results else 0
    
    # Generate report content
    report = f"""# Direct Ollama Test for Role Adherence

## Objective
Test the ability of Ollama's {OLLAMA_MODEL} model to generate role-adherent thoughts without using DSPy.

## Setup
- **API**: Direct Ollama API calls
- **Model**: {OLLAMA_MODEL}
- **Scenarios**: {len(results)} test scenarios (one per role)

## Results
- **Success Rate**: {success_rate:.1%} of examples passed our role-adherence evaluation
- **Average Score**: {sum(r["evaluation"]["score"] for r in results) / len(results) if results else 0:.2f}

## Sample Outputs
"""
    
    # Add details for each test
    for i, result in enumerate(results):
        report += f"""
### Test {i+1}: {result["role"]}
**Situation**: {result["situation"]}

**Generated Thought**:
```
{result["generated_thought"]}
```

**Evaluation**:
- Score: {result["evaluation"]["score"]:.2f}/1.0
- Passed: {"Yes" if result["evaluation"]["passes_threshold"] else "No"}
- Keyword Matches: {result["evaluation"]["keyword_matches"]}
- Contains Role Phrase: {"Yes" if result["evaluation"]["has_role_phrase"] else "No"}

"""
    
    # Add conclusion
    report += """
## Conclusion
This test demonstrates the ability to generate role-adherent thoughts using direct Ollama API calls.
The approach provides a fallback mechanism for role-based thought generation without requiring a full DSPy implementation.

## Next Steps
- Refine the prompt template for better results
- Compare performance across different models
- Implement in the agent system to improve role adherence
"""
    
    # Save report
    with open(output_dir / "direct_ollama_report.md", "w") as f:
        f.write(report)
    
    logger.info(f"Report saved to {output_dir / 'direct_ollama_report.md'}")
    logger.info(f"Raw results saved to {output_dir / 'direct_ollama_results.json'}")

if __name__ == "__main__":
    logger.info("Starting direct Ollama test for role adherence")
    try:
        results = run_test_scenarios()
        create_report(results)
        logger.info("Test completed successfully")
    except Exception as e:
        logger.error(f"Test failed: {e}")
        raise 