#!/usr/bin/env python
"""
Test script for role-specific DSPy summarizers.

This script demonstrates how to use the RoleSpecificSummaryGenerator to generate
summaries tailored to different agent roles.
"""

import sys
import logging
from pathlib import Path

# Add project root to path
project_root = Path(__file__).parent.parent
sys.path.append(str(project_root))

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("role_summary_test.log")
    ]
)
logger = logging.getLogger("role_summarizer_test")

# Import the role-specific summary generator
try:
    from src.agents.dspy_programs.role_specific_summary_generator import RoleSpecificSummaryGenerator
    logger.info("Successfully imported RoleSpecificSummaryGenerator")
except ImportError as e:
    logger.error(f"Failed to import RoleSpecificSummaryGenerator: {e}")
    sys.exit(1)

# Test data for L1 summaries (recent events for each role)
L1_TEST_DATA = {
    "Innovator": {
        "recent_events": """
        - Step 5, Thought: I should propose a new approach to the recommendation algorithm.
        - Step 5, Broadcast Message: "What if we combine collaborative filtering with knowledge graphs to provide more contextually relevant suggestions?"
        - Step 6, Perceived Message: Agent_2 said: "Interesting idea, but wouldn't that be computationally expensive?"
        - Step 6, Thought: That's a valid concern, but I think I can address it.
        - Step 6, Broadcast Message: "We could implement a pruning mechanism to keep the knowledge graph manageable. Early benchmarks suggest a 15% improvement in recommendation relevance."
        - Step 7, Perceived Message: Agent_4 said: "I'd be interested in seeing a small prototype of this approach."
        - Step 7, Thought: This is a good opportunity to demonstrate the concept.
        - Step 7, Broadcast Message: "I'll create a simplified prototype with a subset of data to demonstrate the approach and measure performance impacts."
        """,
        "current_mood": "excited"
    },
    "Analyzer": {
        "recent_events": """
        - Step 12, Thought: I should analyze the recent performance metrics of our recommendation system.
        - Step 12, Broadcast Message: "After analyzing the last month's performance data, I've identified that our recommendation accuracy drops by 17.3% for new users compared to established users."
        - Step 13, Perceived Message: Agent_1 said: "That's concerning. Do we know what's causing this discrepancy?"
        - Step 13, Thought: I need to investigate the root cause of this issue.
        - Step 13, Broadcast Message: "The primary cause appears to be insufficient data for the collaborative filtering algorithm. New users have an average of only 3.2 interactions, while our algorithm typically needs 10+ for reliable predictions."
        - Step 14, Perceived Message: Agent_3 said: "Could we supplement with demographic data for new users?"
        - Step 14, Thought: That's a reasonable approach that I should evaluate with data.
        - Step 14, Broadcast Message: "I'll conduct an A/B test comparing our current approach with a hybrid model that incorporates demographic data for new users. Based on similar cases, we might expect a 30-40% reduction in the accuracy gap."
        """,
        "current_mood": "analytical"
    },
    "Facilitator": {
        "recent_events": """
        - Step 8, Thought: I notice that Agent_1 and Agent_3 seem to be talking past each other about the project priorities.
        - Step 8, Broadcast Message: "I'm noticing some different perspectives on project priorities. Let's take a step back and clarify our goals. What specific outcomes are most important to each of you?"
        - Step 9, Perceived Message: Agent_1 said: "My primary concern is meeting the delivery deadline for the client demo next week."
        - Step 9, Perceived Message: Agent_3 said: "I'm more focused on ensuring the core algorithm is robust and well-tested."
        - Step 10, Thought: These priorities need to be reconciled. I should help find a middle ground.
        - Step 10, Broadcast Message: "Thank you both. It seems we need to balance short-term delivery needs with technical quality. What if we define a minimal viable feature set for the demo that allows us to maintain quality standards for the core components?"
        - Step 11, Perceived Message: Agent_1 said: "That makes sense. We could focus on demonstrating the key features without rushing all functionality."
        - Step 11, Perceived Message: Agent_3 said: "I can work with that approach as long as we don't compromise on the core algorithm testing."
        """,
        "current_mood": "diplomatic"
    }
}

# Test data for L2 summaries (consolidated L1 summaries for each role)
L2_TEST_DATA = {
    "Innovator": {
        "l1_summaries_context": """
        Day 1 Summary: As an Innovator, I proposed a new recommendation system combining collaborative filtering with knowledge graphs to address contextual relevance problems. When challenged about computational complexity, I suggested a pruning mechanism to manage resource usage. Agent_4 requested a prototype demonstration, which I agreed to develop using a subset of data.
        
        Day 2 Summary: I presented my prototype recommendation system, demonstrating a 12.8% relevance improvement with only a 7.3% increase in computational overhead. The team was impressed with the unexpected efficiency, and we discussed scaling strategies. I suggested an incremental implementation approach, starting with high-value user segments before full deployment.
        
        Day 3 Summary: Building on previous discussions, I connected my recommendation system with Agent_2's personalization framework, creating an unexpected synergy that improved both systems. This cross-domain integration sparked additional ideas about adaptive learning mechanisms that could further enhance performance by dynamically adjusting parameters based on user engagement patterns.
        
        Day 4 Summary: After reflecting on implementation challenges, I proposed a novel caching architecture specifically designed for knowledge graph queries that reduced computational overhead by 34%. This breakthrough approach resolved the primary concern about my recommendation system's feasibility for production environments.
        
        Day 5 Summary: I collaborated with the testing team to validate my recommendation system with real user data, uncovering edge cases involving multilingual content where performance degraded. Rather than seeing this as a setback, I developed an innovative cross-lingual embedding technique that not only fixed the issue but improved overall multilingual recommendations by 23%.
        """,
        "overall_mood_trend": "increasingly confident and collaborative",
        "agent_goals": "Develop innovative recommendation systems that balance performance with computational efficiency"
    },
    "Analyzer": {
        "l1_summaries_context": """
        Day 1 Summary: I identified a 17.3% drop in recommendation accuracy for new users compared to established users. Analysis showed this was due to insufficient interaction data (3.2 average interactions versus the 10+ needed for reliable predictions). When Agent_3 suggested supplementing with demographic data, I proposed conducting an A/B test to compare our current approach with a hybrid model incorporating demographic information.
        
        Day 2 Summary: My A/B test revealed that the hybrid model incorporating demographic data reduced the accuracy gap by 32.7% for new users, aligning with my prediction of 30-40% improvement. Further data analysis showed that geographic location and device type were the most predictive demographic factors, while age and gender provided minimal signal. I documented these findings with statistical significance measures (p < 0.01) and confidence intervals.
        
        Day 3 Summary: I performed a detailed segmentation analysis of user retention patterns, identifying four distinct user cohorts with different engagement trajectories. The analysis revealed that "early explorers" (users who view multiple categories in their first session) have 2.3x higher retention rates despite receiving less personalized recommendations. I constructed a decision tree model to predict which new users would fall into this high-value segment with 76.8% accuracy.
        
        Day 4 Summary: I evaluated the computational efficiency of our recommendation system, measuring processing time and resource utilization across different load scenarios. My benchmarks indicated a quadratic scaling issue that would cause performance problems at projected user growth. I isolated the problem to a specific matrix operation and documented three potential optimization approaches with projected impact metrics for each.
        
        Day 5 Summary: Through systematic A/B testing of notification timing, I determined that personalized recommendations delivered between 6-8 PM local time increased engagement by 27.4% compared to our fixed-time approach. My analysis controlled for confounding variables including day of week, user segment, and content freshness, with all results achieving statistical significance (p < 0.005).
        """,
        "overall_mood_trend": "methodical and increasingly confident",
        "agent_goals": "Optimize system performance through rigorous data analysis and evidence-based improvements"
    },
    "Facilitator": {
        "l1_summaries_context": """
        Day 1 Summary: I identified communication gaps between Agent_1 (prioritizing client deadline) and Agent_3 (focused on algorithm quality). By facilitating a structured discussion about priorities, I helped the team reach consensus on a minimal viable feature set for the demo that preserved core algorithm quality while meeting the client deadline. Both agents expressed satisfaction with this balanced approach.
        
        Day 2 Summary: During our planning session, I noticed rising tensions around resource allocation. I organized a collaborative exercise where team members visualized workflow dependencies, which revealed hidden bottlenecks. This process helped establish a shared understanding of constraints and led to a reorganized sprint plan that all participants supported enthusiastically.
        
        Day 3 Summary: When technical disagreements emerged between the frontend and backend teams about API design, I facilitated a solution-focused workshop. By establishing clear evaluation criteria upfront and moderating the discussion to ensure all perspectives were heard, we reached consensus on a flexible API design that accommodated both teams' needs. I documented the agreed architecture and decision rationale for future reference.
        
        Day 4 Summary: Recognizing that team communication was becoming fragmented across multiple channels, I established a communication protocol that clarified which platforms to use for different types of information. I also implemented daily synchronous standups and created designated spaces for asynchronous updates. Team members reported feeling better informed and less overwhelmed by the end of the day.
        
        Day 5 Summary: I noticed that decision-making processes were becoming delayed due to unclear ownership. Through one-on-one conversations, I identified institutional knowledge gaps and authority uncertainties. I facilitated a responsibility assignment workshop using the RACI matrix framework, which clarified decision rights and increased team confidence in moving initiatives forward independently.
        """,
        "overall_mood_trend": "consistently positive and solution-oriented",
        "agent_goals": "Foster effective team collaboration by improving communication and resolving conflicts"
    }
}

def test_l1_summarizers():
    """Test role-specific L1 summarizers with sample data."""
    logger.info("Testing role-specific L1 summarizers")
    
    # Create the role-specific summary generator
    generator = RoleSpecificSummaryGenerator()
    
    # Test each role
    for role, data in L1_TEST_DATA.items():
        logger.info(f"\n{'=' * 30}\nGenerating L1 summary for {role} role\n{'=' * 30}")
        
        # Generate the summary
        summary = generator.generate_l1_summary(
            agent_role=role,
            recent_events=data["recent_events"],
            current_mood=data["current_mood"]
        )
        
        # Display the result
        logger.info(f"Role: {role}")
        logger.info(f"Current Mood: {data['current_mood']}")
        logger.info(f"Summary:\n{summary}\n")
        
        # Also print to console
        print(f"\n{'=' * 30}\nL1 Summary for {role} role\n{'=' * 30}")
        print(f"Current Mood: {data['current_mood']}")
        print(f"\n{summary}\n")

def test_l2_summarizers():
    """Test role-specific L2 summarizers with sample data."""
    logger.info("Testing role-specific L2 summarizers")
    
    # Create the role-specific summary generator
    generator = RoleSpecificSummaryGenerator()
    
    # Test each role
    for role, data in L2_TEST_DATA.items():
        logger.info(f"\n{'=' * 30}\nGenerating L2 summary for {role} role\n{'=' * 30}")
        
        # Generate the summary
        summary = generator.generate_l2_summary(
            agent_role=role,
            l1_summaries_context=data["l1_summaries_context"],
            overall_mood_trend=data["overall_mood_trend"],
            agent_goals=data["agent_goals"]
        )
        
        # Display the result
        logger.info(f"Role: {role}")
        logger.info(f"Mood Trend: {data['overall_mood_trend']}")
        logger.info(f"Goals: {data['agent_goals']}")
        logger.info(f"Summary:\n{summary}\n")
        
        # Also print to console
        print(f"\n{'=' * 30}\nL2 Summary for {role} role\n{'=' * 30}")
        print(f"Mood Trend: {data['overall_mood_trend']}")
        print(f"Goals: {data['agent_goals']}")
        print(f"\n{summary}\n")

if __name__ == "__main__":
    logger.info("Starting role-specific summarizer tests")
    
    test_l1_summarizers()
    test_l2_summarizers()
    
    logger.info("Role-specific summarizer tests completed") 