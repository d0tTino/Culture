# Role Adherence Experiments for Culture.ai

This directory contains experiments, tools, and implementation suggestions for improving role adherence in agent thought generation.

## Overview

The objective of these experiments was to test different approaches to ensure that agent thoughts consistently reflect their assigned roles (Innovator, Analyzer, Facilitator). We explored:

1. DSPy-based prompt optimization
2. Direct prompt engineering with Ollama
3. Simplified verification metrics for role adherence

## Files in this Directory

- `dspy_role_adherence_experiment.py`: Main DSPy experiment script
- `direct_ollama_test.py`: Direct approach using Ollama API
- `simplified_role_adherence.py`: Standalone verification mechanism
- `role_adherence_implementation_recommendations.md`: Detailed implementation suggestions
- `role_adherence_implementation_example.py`: Code examples for integration
- `dspy_experiment_summary.md`: Overall summary of findings and recommendations

## Running the Experiments

### DSPy Experiment

```bash
# Install DSPy first
pip install -U dspy-ai

# Run the DSPy experiment
python experiments/dspy_role_adherence_experiment.py
```

### Direct Ollama Test

```bash
# Run the direct Ollama test
python experiments/direct_ollama_test.py
```

### Simplified Role Adherence Test

```bash
# Run the simplified role adherence verification test
python experiments/simplified_role_adherence.py
```

## Key Findings

Our experiments showed that:

1. Explicitly instructing agents to begin thoughts with "As a [role]" significantly improved role adherence.
2. Role-specific keywords are effective indicators of proper role adherence.
3. A simple scoring system combining keyword matching and role phrases achieved 83.3% accuracy in identifying role-adherent thoughts.
4. While DSPy offers a promising framework, direct prompt engineering provided immediate results with less complexity.

## Implementation Path

We recommend a three-phase approach:

1. **Phase 1**: Implement the enhanced prompt template in `generate_thought_and_message_node`
2. **Phase 2**: Add the verification function to measure and track role adherence
3. **Phase 3**: Implement advanced features like automatic regeneration of low-adherence thoughts

For detailed implementation guidance, see `role_adherence_implementation_recommendations.md`.

## Next Steps

1. Review the suggestions in `role_adherence_implementation_recommendations.md`
2. Implement the basic prompt enhancements in the agent graph
3. Run a test simulation to verify improvements in role adherence
4. Consider implementing the verification metrics for ongoing monitoring 