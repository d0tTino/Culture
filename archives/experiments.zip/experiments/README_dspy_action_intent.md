# DSPy Action Intent Selection Experiment

## Overview

This directory contains an experiment to optimize agent action intent selection using DSPy (Declarative Self-improving Python). The goal is to improve how agents choose appropriate actions based on their role, current situation, and goals.

## Files

- `dspy_action_intent_experiment.py`: The main experiment script that configures DSPy with Ollama, defines the signature for action intent selection, creates a training dataset, and optimizes the module.
- `manual_action_intent_examples.py`: A simulation of expected DSPy outputs for demonstration purposes.
- `dspy_action_intent_report.md`: Comprehensive report on the experiment design, implementation, and findings.
- `simulated_action_intent_report.json`: JSON output of the simulated DSPy results.
- `action_intent_experiment.log`: Log file of the experiment run.

## Prerequisites

- DSPy installed: `pip install dspy`
- Ollama installed and running: [https://ollama.ai/](https://ollama.ai/)
- Mistral model pulled in Ollama: `ollama pull mistral`

## Running the Experiment

To run the full DSPy experiment:

```bash
python dspy_action_intent_experiment.py
```

This will attempt to:
1. Configure DSPy with a local Ollama instance
2. Define a ChainOfThought module for action intent selection
3. Create a training dataset of diverse examples
4. Optimize the module using BootstrapFewShot
5. Test the optimized module on new examples
6. Generate a report of the results

To run the simulated version (which doesn't require DSPy to be working):

```bash
python manual_action_intent_examples.py
```

This will generate simulated outputs based on role-appropriate reasoning patterns.

## Integration with the Agent Architecture

The optimized DSPy module is designed to be integrated into `generate_thought_and_message_node` in the agent graph. The report provides detailed guidance on two integration approaches:

1. **Full Replacement**: Using the DSPy module to directly determine the action_intent and justification
2. **Augmentation** (Recommended): Using the DSPy module to suggest an action_intent and justification, which is then passed as context to the main LLM call

## Outputs

The experiment's primary outputs include:
- An optimized DSPy module for action intent selection
- A report detailing the optimization process and findings
- Test results showing the module's performance on new examples
- Integration recommendations for the main agent architecture 