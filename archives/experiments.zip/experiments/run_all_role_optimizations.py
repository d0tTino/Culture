#!/usr/bin/env python
"""
Script to run all role-specific summarizer optimizations sequentially.

This script executes both L1 and L2 optimizations for all roles, collecting
results and generating a summary report.
"""

import os
import sys
import logging
import subprocess
import json
import datetime
from pathlib import Path
from typing import Dict, List, Any

# Add project root to path
project_root = Path(__file__).parent.parent
sys.path.append(str(project_root))

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("role_optimization_run.log")
    ]
)
logger = logging.getLogger("role_optimization_runner")

def run_optimization_script(script_path: str) -> bool:
    """
    Run an optimization script and return success status.
    
    Args:
        script_path: Path to the optimization script
        
    Returns:
        bool: True if script executed successfully
    """
    logger.info(f"Running {script_path}")
    try:
        result = subprocess.run(
            [sys.executable, script_path],
            check=True,
            capture_output=True,
            text=True
        )
        logger.info(f"Successfully executed {script_path}")
        return True
    except subprocess.CalledProcessError as e:
        logger.error(f"Failed to execute {script_path}: {e}")
        logger.error(f"STDOUT: {e.stdout}")
        logger.error(f"STDERR: {e.stderr}")
        return False

def collect_optimization_results() -> Dict[str, Any]:
    """
    Collect results from optimization report files.
    
    Returns:
        Dict with collected results
    """
    results = {
        "l1_summarizers": {},
        "l2_summarizers": {},
        "timestamp": datetime.datetime.now().isoformat()
    }
    
    # Define roles
    roles = ["innovator", "analyzer", "facilitator"]
    
    # Collect L1 results
    for role in roles:
        report_path = os.path.join(project_root, "experiments", f"l1_{role}_summarizer_optimization_report.json")
        if os.path.exists(report_path):
            with open(report_path, 'r') as f:
                role_results = json.load(f)
                results["l1_summarizers"][role] = role_results
        else:
            results["l1_summarizers"][role] = {"status": "No report found"}
    
    # Collect L2 results
    for role in roles:
        report_path = os.path.join(project_root, "experiments", f"l2_{role}_summarizer_optimization_report.json")
        if os.path.exists(report_path):
            with open(report_path, 'r') as f:
                role_results = json.load(f)
                results["l2_summarizers"][role] = role_results
        else:
            results["l2_summarizers"][role] = {"status": "No report found"}
    
    return results

def save_consolidated_report(results: Dict[str, Any]) -> None:
    """
    Save a consolidated report of all optimization results.
    
    Args:
        results: Dictionary with collected results
    """
    report_path = os.path.join(project_root, "experiments", "role_summarizers_consolidated_report.json")
    with open(report_path, 'w') as f:
        json.dump(results, f, indent=2)
    logger.info(f"Saved consolidated report to {report_path}")

def display_summary(results: Dict[str, Any]) -> None:
    """
    Display a summary of optimization results.
    
    Args:
        results: Dictionary with collected results
    """
    print("\n" + "=" * 60)
    print(" ROLE-SPECIFIC SUMMARIZER OPTIMIZATION SUMMARY ")
    print("=" * 60)
    
    # L1 Summarizers
    print("\nL1 SUMMARIZERS:")
    for role, data in results["l1_summarizers"].items():
        if "status" in data:
            print(f"  {role.capitalize()}: {data['status']}")
        else:
            improvement = data.get("percent_improvement", "N/A")
            if isinstance(improvement, float):
                improvement = f"{improvement:.2f}%"
            print(f"  {role.capitalize()}: Improvement: {improvement}")
    
    # L2 Summarizers
    print("\nL2 SUMMARIZERS:")
    for role, data in results["l2_summarizers"].items():
        if "status" in data:
            print(f"  {role.capitalize()}: {data['status']}")
        else:
            improvement = data.get("percent_improvement", "N/A")
            if isinstance(improvement, float):
                improvement = f"{improvement:.2f}%"
            print(f"  {role.capitalize()}: Improvement: {improvement}")
    
    # Check for compiled models
    compiled_dir = os.path.join(project_root, "src", "agents", "dspy_programs", "compiled")
    print("\nCOMPILED MODELS:")
    if os.path.exists(compiled_dir):
        models = os.listdir(compiled_dir)
        role_models = [model for model in models if "innovator" in model or "analyzer" in model or "facilitator" in model]
        
        if role_models:
            for model in role_models:
                print(f"  {model}")
        else:
            print("  No role-specific compiled models found.")
    else:
        print("  Compiled directory not found.")
    
    print("\n" + "=" * 60)

def main():
    """Main function to run all optimizations."""
    logger.info("Starting role-specific summarizer optimizations")
    
    # Scripts to run
    scripts = [
        "experiments/optimize_role_l1_summarizers.py",
        "experiments/optimize_role_l2_summarizers.py"
    ]
    
    # Run each script
    results = []
    for script in scripts:
        script_path = os.path.join(project_root, script)
        if os.path.exists(script_path):
            success = run_optimization_script(script_path)
            results.append({"script": script, "success": success})
        else:
            logger.error(f"Script not found: {script_path}")
            results.append({"script": script, "success": False, "error": "File not found"})
    
    # Collect and save results
    logger.info("Collecting optimization results")
    collected_results = collect_optimization_results()
    collected_results["script_executions"] = results
    
    # Save consolidated report
    save_consolidated_report(collected_results)
    
    # Display summary
    display_summary(collected_results)
    
    logger.info("Completed role-specific summarizer optimizations")

if __name__ == "__main__":
    main() 