# Culture.AI Performance Benchmarks

This directory contains tools and scripts for benchmarking the performance of various components of the Culture.AI system.

## Available Benchmarks

### MUS Pruning Performance Benchmarks

The `benchmark_vector_store_mus.py` script measures the performance impact of Memory Utility Score (MUS) calculations in the ChromaVectorStoreManager.

#### Purpose

The MUS pruning benchmark measures:
- Performance overhead of MUS metadata updates during memory operations
- Performance comparison between MUS-based and age-based pruning strategies
- Memory and CPU usage differences with MUS enabled vs. disabled

#### Usage

To run the MUS pruning benchmark with default settings:

```bash
python benchmarks/benchmark_vector_store_mus.py
```

This will run both baseline (without MUS calculations) and MUS-enabled scenarios with default settings.

#### Options

- `--memories NUM`: Number of raw memories to add (default: 1000)
- `--l1_summaries NUM`: Number of L1 summaries to add (default: 100)
- `--l2_summaries NUM`: Number of L2 summaries to add (default: 20)
- `--queries NUM`: Number of retrieval queries to perform (default: 100)
- `--runs NUM`: Number of runs per scenario for averaging (default: 3)
- `--scenario {baseline,mus_enabled,both}`: Which scenarios to run (default: both)

#### Example: Running a larger benchmark

```bash
python benchmarks/benchmark_vector_store_mus.py --memories 5000 --queries 500 --runs 5
```

#### Example: Comparing only MUS-enabled performance

```bash
python benchmarks/benchmark_vector_store_mus.py --scenario mus_enabled
```

#### Output

The benchmark generates three output files:
- `benchmarks/vector_store_mus_benchmark_report.md`: A human-readable report with performance analysis
- `benchmarks/vector_store_mus_benchmark_raw_results.json`: Raw benchmark data in JSON format
- `benchmarks/vector_store_mus_performance_analysis.md`: Comprehensive analysis with optimization recommendations

## Analysis and Reports

### MUS Pruning Performance Analysis

A detailed analysis of MUS pruning performance is available in [vector_store_mus_performance_analysis.md](vector_store_mus_performance_analysis.md). This document provides:

- Executive summary of findings
- Detailed analysis of performance impact across different operations
- Performance comparisons between MUS-based and age-based pruning
- Optimization recommendations for large-scale deployments

Key findings from the analysis:
- MUS adds ~9% overhead to retrieval operations
- L1 summary addition sees the largest impact (~92% overhead)
- Pruning candidate identification with MUS is 12-13% slower than age-based approaches
- The overhead is justified by improved memory management quality

## Requirements

The benchmarks require:
- Python 3.8+
- psutil package (`pip install psutil`)
- All Culture.AI dependencies

## Adding New Benchmarks

When adding new benchmarks, please:
1. Create a script named `benchmark_<component>_<feature>.py`
2. Generate reports in both markdown and raw (JSON) formats
3. Update this README to document the new benchmark 