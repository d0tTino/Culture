#!/usr/bin/env python3
"""
Script to integrate RAG assessment scores from the operator-filled CSV template
into the corresponding JSON assessment files for each scenario.
"""

import csv
import json
import os
from pathlib import Path

def load_csv_data(csv_path):
    """
    Load the filled RAG assessment CSV data.
    
    Args:
        csv_path: Path to the filled CSV file
        
    Returns:
        List of dictionaries representing rows from the CSV
    """
    data = []
    try:
        with open(csv_path, 'r', newline='') as csvfile:
            reader = csv.DictReader(csvfile)
            for row in reader:
                # Convert query_id to integer for easier comparison
                try:
                    row['query_id'] = int(row['query_id'])
                    
                    # Validate qualitative_score
                    if row['qualitative_score']:
                        row['qualitative_score'] = int(row['qualitative_score'])
                        # Ensure score is in range 1-5
                        if row['qualitative_score'] < 1 or row['qualitative_score'] > 5:
                            print(f"Warning: Score for {row['scenario_name']}, {row['agent_id']}, query {row['query_id']} is out of range (1-5): {row['qualitative_score']}")
                    else:
                        print(f"Warning: Missing score for {row['scenario_name']}, {row['agent_id']}, query {row['query_id']}")
                        row['qualitative_score'] = None
                        
                    data.append(row)
                except ValueError:
                    print(f"Warning: Invalid query_id or score format in row: {row}")
                    
        return data
    except Exception as e:
        print(f"Error loading CSV file: {e}")
        return []

def update_json_assessment_file(scenario, csv_data):
    """
    Update the JSON assessment file for a specific scenario with scores from CSV data.
    
    Args:
        scenario: Scenario name
        csv_data: List of CSV rows containing assessment data
        
    Returns:
        Boolean indicating success/failure
    """
    # Construct path to the JSON assessment file
    script_dir = Path(__file__).parent
    json_file_path = script_dir.parent / "tuning_results" / scenario / "rag_assessment" / f"{scenario}_rag_assessment.json"
    
    # Filter CSV data for this scenario
    scenario_data = [row for row in csv_data if row['scenario_name'] == scenario]
    if not scenario_data:
        print(f"No assessment data found for scenario: {scenario}")
        return False
    
    # Load existing JSON if it exists, or create new structure
    try:
        if json_file_path.exists():
            with open(json_file_path, 'r') as f:
                assessment_data = json.load(f)
        else:
            # Create directory if it doesn't exist
            json_file_path.parent.mkdir(parents=True, exist_ok=True)
            
            # Create base JSON structure
            assessment_data = {
                "scenario_id": scenario,
                "query_assessments": {},
                "overall_metrics": {
                    "avg_score": 0.0,
                    "query_count": 0,
                    "success_rate": 0.0
                }
            }
        
        # Initialize or update query_assessments structure
        if "query_assessments" not in assessment_data:
            assessment_data["query_assessments"] = {}
        
        # Update with data from CSV
        for row in scenario_data:
            agent_id = row['agent_id']
            query_id = row['query_id']
            
            # Skip rows with missing scores
            if row['qualitative_score'] is None:
                continue
            
            # Create keys if they don't exist
            if str(query_id) not in assessment_data["query_assessments"]:
                assessment_data["query_assessments"][str(query_id)] = {"agents": {}}
                
            # Update agent data for this query
            assessment_data["query_assessments"][str(query_id)]["agents"][agent_id] = {
                "qualitative_score": row['qualitative_score'],
                "assessment_notes": row['assessment_notes'],
                "response_file": row['response_file_path']
            }
        
        # Calculate updated metrics
        total_score = 0
        total_assessments = 0
        success_count = 0
        
        for query_id, query_data in assessment_data["query_assessments"].items():
            for agent_id, agent_data in query_data["agents"].items():
                if "qualitative_score" in agent_data:
                    score = agent_data["qualitative_score"]
                    total_score += score
                    total_assessments += 1
                    
                    # Count as successful if score is 3 or higher
                    if score >= 3:
                        success_count += 1
        
        # Update overall metrics
        if total_assessments > 0:
            assessment_data["overall_metrics"]["avg_score"] = round(total_score / total_assessments, 2)
            assessment_data["overall_metrics"]["query_count"] = total_assessments
            assessment_data["overall_metrics"]["success_rate"] = round(success_count / total_assessments, 2)
        
        # Write updated JSON
        with open(json_file_path, 'w') as f:
            json.dump(assessment_data, f, indent=2)
            
        print(f"Updated assessment file for {scenario}: {json_file_path}")
        return True
    
    except Exception as e:
        print(f"Error updating JSON file for {scenario}: {e}")
        return False

def main():
    # Get path to the filled CSV template
    script_dir = Path(__file__).parent
    csv_path = script_dir / "rag_assessment_template.csv"
    
    if not csv_path.exists():
        print(f"Error: CSV file not found at {csv_path}")
        print("Please run generate_rag_csv_template.py first and fill the CSV with assessment scores.")
        return
    
    # Load data from CSV
    print(f"Loading assessment data from {csv_path}")
    csv_data = load_csv_data(csv_path)
    
    if not csv_data:
        print("No valid assessment data found in CSV file.")
        return
    
    # Get unique scenarios from the CSV data
    scenarios = list(set(row['scenario_name'] for row in csv_data))
    print(f"Found {len(scenarios)} scenarios in the CSV data.")
    
    # Update assessment files for each scenario
    success_count = 0
    for scenario in scenarios:
        if update_json_assessment_file(scenario, csv_data):
            success_count += 1
    
    print(f"Successfully updated {success_count} out of {len(scenarios)} assessment files.")
    print("Next steps: Run finalize_report_data.py to update the comparative data with these assessments.")

if __name__ == "__main__":
    main() 