#!/usr/bin/env python3
"""
Script to generate a CSV template for RAG assessment by operators.
This template will be used to collect qualitative assessments of RAG query responses.
"""

import csv
import os
from pathlib import Path

def main():
    # Define all scenario IDs from the tuning experiments
    scenarios = [
        "baseline",
        "mus_very_low",
        "mus_low",
        "mus_medium_low",
        "mus_medium",
        "mus_medium_high",
        "mus_high",
        "mus_very_high",
        "l1_low_l2_medium",
        "l1_medium_l2_low",
        "l1_only",
        "l2_only",
        "age_based_only"
    ]
    
    # Define the standard RAG queries used in the assessment
    queries = {
        0: "What information do you recall about technical projects from last month?",
        1: "Summarize the key points from our team meeting about database optimization.",
        2: "What were the major customer concerns raised in recent support tickets?"
    }
    
    # Define agent IDs
    agent_ids = ["agent_1", "agent_2", "agent_3", "agent_4"]
    
    # Create output directory if it doesn't exist
    script_dir = Path(__file__).parent
    
    # Output file path
    output_file = script_dir / "rag_assessment_template.csv"
    
    # CSV header
    header = [
        "scenario_name", 
        "agent_id", 
        "query_id", 
        "query_text", 
        "response_file_path", 
        "qualitative_score", 
        "assessment_notes"
    ]
    
    print(f"Generating RAG assessment template: {output_file}")
    
    # Generate CSV with template rows
    with open(output_file, 'w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        
        # Write header
        writer.writerow(header)
        
        # Generate rows for every scenario, agent, and query combination
        for scenario in scenarios:
            for agent_id in agent_ids:
                for query_id in queries:
                    # Construct the relative path to the response file
                    response_file_path = f"../tuning_results/{scenario}/rag_assessment/{agent_id}_response_{query_id}.txt"
                    
                    # Create row with empty score and notes
                    row = [
                        scenario,
                        agent_id,
                        query_id,
                        queries[query_id],
                        response_file_path,
                        "",  # Empty qualitative_score for operator to fill
                        ""   # Empty assessment_notes for operator to fill
                    ]
                    
                    writer.writerow(row)
    
    print(f"Template generated with {len(scenarios) * len(agent_ids) * len(queries)} assessment rows.")
    print("Please distribute this template to operators for qualitative RAG assessment.")

if __name__ == "__main__":
    main() 