#!/usr/bin/env python
"""
Benchmark script for measuring the performance impact of Memory Utility Score (MUS) pruning.

This script runs performance tests comparing the system's behavior with MUS pruning
enabled vs. disabled, measuring metrics like execution time, CPU usage, and memory usage.

Usage:
    python benchmarks/benchmark_mus_pruning.py --scenario baseline
    python benchmarks/benchmark_mus_pruning.py --scenario mus_enabled
"""

import os
import sys
import time
import logging
import argparse
import psutil
import json
import statistics
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple
import shutil

# Add the project root to the Python path
project_root = str(Path(__file__).parent.parent)
sys.path.append(project_root)

# Import simulation components
from src.sim.simulation import Simulation
from src.sim.knowledge_board import KnowledgeBoard
from src.infra.llm_client import get_ollama_client
from src.agents.core.base_agent import Agent
from src.agents.memory.vector_store import ChromaVectorStoreManager
import src.infra.config as config

# Configure logging for benchmark
os.makedirs("benchmarks", exist_ok=True)
log_file = f"benchmarks/mus_benchmark_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler(log_file)
    ]
)

# Set specific module loggers to higher levels to reduce noise
logging.getLogger('src.infra.llm_client').setLevel(logging.WARNING)
logging.getLogger('src.agents.core.agent_state').setLevel(logging.WARNING)

logger = logging.getLogger("mus_benchmark")

# Test scenario 
BENCHMARK_SCENARIO = """
The team is collaboratively designing an AI system architecture. Each agent should contribute 
ideas based on their role (Innovator, Analyzer, Facilitator) and expertise. The task involves 
complex problem-solving, requiring frequent memory access and consolidation.
"""

# Performance metrics collection 
class PerformanceMonitor:
    """Monitors and records system performance metrics during benchmark runs."""
    
    def __init__(self, sampling_interval: float = 1.0):
        """
        Initialize the performance monitor.
        
        Args:
            sampling_interval: Time between samples in seconds
        """
        self.sampling_interval = sampling_interval
        self.process = psutil.Process(os.getpid())
        self.cpu_samples = []
        self.memory_samples = []
        self.running = False
        self.start_time = None
        self.end_time = None
    
    def start_monitoring(self):
        """Start collecting performance metrics."""
        self.running = True
        self.start_time = time.time()
        self.cpu_samples = []
        self.memory_samples = []
        
        # Collect initial samples
        self._collect_samples()
    
    def stop_monitoring(self):
        """Stop collecting performance metrics."""
        self.running = False
        self.end_time = time.time()
        
        # Collect final samples
        self._collect_samples()
    
    def _collect_samples(self):
        """Collect current CPU and memory usage."""
        cpu_percent = self.process.cpu_percent(interval=None)
        memory_info = self.process.memory_info()
        
        self.cpu_samples.append(cpu_percent)
        self.memory_samples.append(memory_info.rss)  # Resident Set Size in bytes
    
    def get_metrics(self) -> Dict[str, Any]:
        """
        Calculate and return performance metrics.
        
        Returns:
            Dictionary with performance metrics
        """
        if not self.cpu_samples or not self.memory_samples:
            return {
                "error": "No samples collected"
            }
        
        # Calculate elapsed time
        elapsed_time = (self.end_time - self.start_time) if self.end_time else 0
        
        # Calculate CPU metrics
        avg_cpu = statistics.mean(self.cpu_samples) if self.cpu_samples else 0
        max_cpu = max(self.cpu_samples) if self.cpu_samples else 0
        
        # Calculate memory metrics (convert to MB for readability)
        memory_samples_mb = [s / (1024 * 1024) for s in self.memory_samples]
        avg_memory_mb = statistics.mean(memory_samples_mb) if memory_samples_mb else 0
        max_memory_mb = max(memory_samples_mb) if memory_samples_mb else 0
        
        return {
            "elapsed_time_seconds": elapsed_time,
            "avg_cpu_percent": avg_cpu,
            "max_cpu_percent": max_cpu,
            "avg_memory_mb": avg_memory_mb,
            "max_memory_mb": max_memory_mb,
            "num_samples": len(self.cpu_samples)
        }

def configure_baseline():
    """Configure the system for baseline benchmark (MUS pruning disabled)."""
    # Ensure age-based pruning is enabled
    config.MEMORY_PRUNING_ENABLED = True
    config.MEMORY_PRUNING_L2_ENABLED = True
    
    # Disable MUS-based pruning
    config.MEMORY_PRUNING_L1_MUS_ENABLED = False
    config.MEMORY_PRUNING_L2_MUS_ENABLED = False
    
    logger.info("Configured for BASELINE scenario (MUS pruning DISABLED)")
    logger.info(f"  MEMORY_PRUNING_ENABLED: {config.MEMORY_PRUNING_ENABLED}")
    logger.info(f"  MEMORY_PRUNING_L2_ENABLED: {config.MEMORY_PRUNING_L2_ENABLED}")
    logger.info(f"  MEMORY_PRUNING_L1_MUS_ENABLED: {config.MEMORY_PRUNING_L1_MUS_ENABLED}")
    logger.info(f"  MEMORY_PRUNING_L2_MUS_ENABLED: {config.MEMORY_PRUNING_L2_MUS_ENABLED}")

def configure_mus_enabled():
    """Configure the system for MUS-enabled benchmark."""
    # Ensure age-based pruning is enabled
    config.MEMORY_PRUNING_ENABLED = True
    config.MEMORY_PRUNING_L2_ENABLED = True
    
    # Enable MUS-based pruning
    config.MEMORY_PRUNING_L1_MUS_ENABLED = True
    config.MEMORY_PRUNING_L2_MUS_ENABLED = True
    
    logger.info("Configured for MUS ENABLED scenario")
    logger.info(f"  MEMORY_PRUNING_ENABLED: {config.MEMORY_PRUNING_ENABLED}")
    logger.info(f"  MEMORY_PRUNING_L2_ENABLED: {config.MEMORY_PRUNING_L2_ENABLED}")
    logger.info(f"  MEMORY_PRUNING_L1_MUS_ENABLED: {config.MEMORY_PRUNING_L1_MUS_ENABLED}")
    logger.info(f"  MEMORY_PRUNING_L2_MUS_ENABLED: {config.MEMORY_PRUNING_L2_MUS_ENABLED}")
    logger.info(f"  MEMORY_PRUNING_L1_MUS_THRESHOLD: {config.MEMORY_PRUNING_L1_MUS_THRESHOLD}")
    logger.info(f"  MEMORY_PRUNING_L2_MUS_THRESHOLD: {config.MEMORY_PRUNING_L2_MUS_THRESHOLD}")
    logger.info(f"  MEMORY_PRUNING_L1_MUS_CHECK_INTERVAL_STEPS: {config.MEMORY_PRUNING_L1_MUS_CHECK_INTERVAL_STEPS}")
    logger.info(f"  MEMORY_PRUNING_L2_MUS_CHECK_INTERVAL_STEPS: {config.MEMORY_PRUNING_L2_MUS_CHECK_INTERVAL_STEPS}") 

def create_benchmark_simulation(
    num_agents: int = 6,
    steps: int = 500,
    vector_store_dir: str = "./chroma_benchmark_db"
) -> Simulation:
    """
    Creates a simulation for benchmark testing.
    
    Args:
        num_agents: Number of agents in the simulation
        steps: Number of steps to run
        vector_store_dir: Directory path for ChromaDB persistence
        
    Returns:
        A configured Simulation instance
    """
    # Check Ollama availability
    ollama_client = get_ollama_client()
    if not ollama_client:
        logger.error("Failed to connect to Ollama. Please ensure Ollama is running.")
        sys.exit(1)
    
    # Create empty directory for vector store
    os.makedirs(vector_store_dir, exist_ok=True)
    
    # Create the simulation components
    kb = KnowledgeBoard()
    vector_store = ChromaVectorStoreManager(persist_directory=vector_store_dir)
    
    # Create agents with different roles
    agents = []
    roles = ["Innovator", "Analyzer", "Facilitator"]
    
    for i in range(1, num_agents + 1):
        agent_id = f"agent_{i}"
        agent_name = f"Agent_{i}"
        role = roles[(i-1) % len(roles)]  # Assign roles in rotation
        
        agent = Agent(agent_id=agent_id, name=agent_name)
        agent.state.current_role = role  # Set initial role
        agents.append(agent)
        
        logger.info(f"Created agent {agent_id} with role {role}")
    
    # Create the simulation with the agents
    sim = Simulation(
        agents=agents,
        vector_store_manager=vector_store,
        scenario=BENCHMARK_SCENARIO,
        discord_bot=None
    )
    
    # Set the knowledge board
    sim.knowledge_board = kb
    
    # Set the number of steps
    sim.steps_to_run = steps
    
    return sim

def run_benchmark(
    scenario: str,
    num_agents: int = 6,
    steps: int = 500,
    runs: int = 3
) -> List[Dict[str, Any]]:
    """
    Run benchmark tests for the specified scenario.
    
    Args:
        scenario: Benchmark scenario ('baseline' or 'mus_enabled')
        num_agents: Number of agents to use
        steps: Number of simulation steps per run
        runs: Number of benchmark runs
        
    Returns:
        List of performance metrics for each run
    """
    # Configure for the specified scenario
    if scenario == 'baseline':
        configure_baseline()
    elif scenario == 'mus_enabled':
        configure_mus_enabled()
    else:
        logger.error(f"Unknown scenario: {scenario}")
        sys.exit(1)
    
    results = []
    
    for run in range(1, runs + 1):
        logger.info(f"Starting benchmark run {run}/{runs} for scenario {scenario}")
        
        # Create a unique vector store directory for this run
        timestamp = int(time.time())
        vector_store_dir = f"./chroma_benchmark_{scenario}_{timestamp}"
        
        try:
            # Create and configure the simulation
            sim = create_benchmark_simulation(
                num_agents=num_agents,
                steps=steps,
                vector_store_dir=vector_store_dir
            )
            
            # Initialize performance monitoring
            monitor = PerformanceMonitor(sampling_interval=1.0)
            
            # Start timing and monitoring
            start_time = time.time()
            monitor.start_monitoring()
            
            # Run the simulation
            logger.info(f"Running {steps} simulation steps...")
            sim.run(steps)
            
            # Stop timing and monitoring
            end_time = time.time()
            monitor.stop_monitoring()
            
            # Calculate elapsed time
            elapsed_time = end_time - start_time
            steps_per_second = steps / elapsed_time if elapsed_time > 0 else 0
            
            # Get disk usage
            vector_store_size = get_directory_size(vector_store_dir)
            
            # Get performance metrics
            perf_metrics = monitor.get_metrics()
            
            # Add additional metrics
            run_metrics = {
                "run": run,
                "scenario": scenario,
                "num_agents": num_agents,
                "steps": steps,
                "elapsed_time": elapsed_time,
                "steps_per_second": steps_per_second,
                "vector_store_size_mb": vector_store_size / (1024 * 1024),
                **perf_metrics
            }
            
            # Collect memory retrieval metrics if available
            if hasattr(sim.vector_store_manager, 'retrieval_times'):
                retrieval_times = sim.vector_store_manager.retrieval_times
                if retrieval_times:
                    run_metrics["avg_retrieval_time"] = statistics.mean(retrieval_times)
                    run_metrics["max_retrieval_time"] = max(retrieval_times)
                    run_metrics["min_retrieval_time"] = min(retrieval_times)
                    run_metrics["total_retrievals"] = len(retrieval_times)
            
            # Add to results
            results.append(run_metrics)
            
            # Log the metrics
            logger.info(f"Run {run} completed:")
            logger.info(f"  Elapsed time: {elapsed_time:.2f} seconds")
            logger.info(f"  Steps per second: {steps_per_second:.2f}")
            logger.info(f"  Average CPU: {perf_metrics['avg_cpu_percent']:.2f}%")
            logger.info(f"  Average memory: {perf_metrics['avg_memory_mb']:.2f} MB")
            logger.info(f"  Vector store size: {run_metrics['vector_store_size_mb']:.2f} MB")
            
        except Exception as e:
            logger.error(f"Error in benchmark run {run}: {e}")
        
        finally:
            # Clean up the vector store directory
            logger.info(f"Cleaning up vector store directory: {vector_store_dir}")
            try:
                shutil.rmtree(vector_store_dir)
            except Exception as e:
                logger.warning(f"Error cleaning up vector store directory: {e}")
    
    return results

def get_directory_size(path: str) -> int:
    """
    Calculate the total size of a directory in bytes.
    
    Args:
        path: Directory path
        
    Returns:
        Directory size in bytes
    """
    total_size = 0
    
    for dirpath, dirnames, filenames in os.walk(path):
        for f in filenames:
            fp = os.path.join(dirpath, f)
            try:
                total_size += os.path.getsize(fp)
            except Exception as e:
                logger.warning(f"Error getting size of {fp}: {e}")
    
    return total_size 

def analyze_results(baseline_results: List[Dict[str, Any]], mus_results: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Analyze and compare results from baseline and MUS-enabled runs.
    
    Args:
        baseline_results: Results from baseline runs
        mus_results: Results from MUS-enabled runs
        
    Returns:
        Dict containing comparative analysis
    """
    if not baseline_results or not mus_results:
        return {"error": "Insufficient data for analysis"}
    
    # Calculate averages for each scenario
    def calculate_averages(results):
        return {
            "avg_elapsed_time": statistics.mean([r["elapsed_time"] for r in results]),
            "avg_steps_per_second": statistics.mean([r["steps_per_second"] for r in results]),
            "avg_cpu_percent": statistics.mean([r["avg_cpu_percent"] for r in results]),
            "avg_memory_mb": statistics.mean([r["avg_memory_mb"] for r in results]),
            "avg_vector_store_size_mb": statistics.mean([r["vector_store_size_mb"] for r in results])
        }
    
    baseline_avg = calculate_averages(baseline_results)
    mus_avg = calculate_averages(mus_results)
    
    # Calculate percentage differences
    def percent_diff(baseline, mus):
        return ((mus - baseline) / baseline) * 100 if baseline != 0 else 0
    
    comparison = {
        "elapsed_time_diff_percent": percent_diff(
            baseline_avg["avg_elapsed_time"], 
            mus_avg["avg_elapsed_time"]
        ),
        "steps_per_second_diff_percent": percent_diff(
            baseline_avg["avg_steps_per_second"], 
            mus_avg["avg_steps_per_second"]
        ),
        "cpu_usage_diff_percent": percent_diff(
            baseline_avg["avg_cpu_percent"], 
            mus_avg["avg_cpu_percent"]
        ),
        "memory_usage_diff_percent": percent_diff(
            baseline_avg["avg_memory_mb"], 
            mus_avg["avg_memory_mb"]
        ),
        "vector_store_size_diff_percent": percent_diff(
            baseline_avg["avg_vector_store_size_mb"], 
            mus_avg["avg_vector_store_size_mb"]
        )
    }
    
    # Combine all metrics
    analysis = {
        "baseline": baseline_avg,
        "mus_enabled": mus_avg,
        "comparison": comparison
    }
    
    return analysis

def generate_report(
    baseline_results: List[Dict[str, Any]], 
    mus_results: List[Dict[str, Any]],
    analysis: Dict[str, Any]
) -> str:
    """
    Generate a Markdown report of benchmark results.
    
    Args:
        baseline_results: Results from baseline runs
        mus_results: Results from MUS-enabled runs
        analysis: Comparative analysis
        
    Returns:
        Markdown formatted report
    """
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    # Extract some configuration details
    num_agents = baseline_results[0]["num_agents"] if baseline_results else "N/A"
    steps = baseline_results[0]["steps"] if baseline_results else "N/A"
    
    report = f"""# MUS Pruning Performance Benchmark Report

## Overview

This report presents the results of performance benchmarking for Memory Utility Score (MUS) pruning in the Culture.AI system.

- **Date:** {timestamp}
- **Agents:** {num_agents}
- **Simulation Steps:** {steps}
- **Benchmark Runs:** {len(baseline_results)} per scenario

## Benchmark Configuration

### Baseline Scenario
- Age-based pruning enabled
- MUS pruning disabled

### MUS-Enabled Scenario
- Age-based pruning enabled
- MUS pruning enabled
- L1 MUS threshold: {config.MEMORY_PRUNING_L1_MUS_THRESHOLD}
- L2 MUS threshold: {config.MEMORY_PRUNING_L2_MUS_THRESHOLD}

## Results Summary

| Metric | Baseline | MUS Enabled | Difference |
|--------|----------|-------------|------------|
| Execution Time (s) | {analysis["baseline"]["avg_elapsed_time"]:.2f} | {analysis["mus_enabled"]["avg_elapsed_time"]:.2f} | {analysis["comparison"]["elapsed_time_diff_percent"]:.2f}% |
| Steps/Second | {analysis["baseline"]["avg_steps_per_second"]:.2f} | {analysis["mus_enabled"]["avg_steps_per_second"]:.2f} | {analysis["comparison"]["steps_per_second_diff_percent"]:.2f}% |
| CPU Usage (%) | {analysis["baseline"]["avg_cpu_percent"]:.2f} | {analysis["mus_enabled"]["avg_cpu_percent"]:.2f} | {analysis["comparison"]["cpu_usage_diff_percent"]:.2f}% |
| Memory Usage (MB) | {analysis["baseline"]["avg_memory_mb"]:.2f} | {analysis["mus_enabled"]["avg_memory_mb"]:.2f} | {analysis["comparison"]["memory_usage_diff_percent"]:.2f}% |
| Vector Store Size (MB) | {analysis["baseline"]["avg_vector_store_size_mb"]:.2f} | {analysis["mus_enabled"]["avg_vector_store_size_mb"]:.2f} | {analysis["comparison"]["vector_store_size_diff_percent"]:.2f}% |

## Detailed Results

### Baseline Runs
"""
    
    # Add baseline run details
    for i, run in enumerate(baseline_results):
        report += f"""
#### Run {i+1}
- Elapsed Time: {run['elapsed_time']:.2f} s
- Steps/Second: {run['steps_per_second']:.2f}
- Avg CPU: {run['avg_cpu_percent']:.2f}%
- Max CPU: {run['max_cpu_percent']:.2f}%
- Avg Memory: {run['avg_memory_mb']:.2f} MB
- Max Memory: {run['max_memory_mb']:.2f} MB
- Vector Store Size: {run['vector_store_size_mb']:.2f} MB
"""
    
    report += """
### MUS-Enabled Runs
"""
    
    # Add MUS-enabled run details
    for i, run in enumerate(mus_results):
        report += f"""
#### Run {i+1}
- Elapsed Time: {run['elapsed_time']:.2f} s
- Steps/Second: {run['steps_per_second']:.2f}
- Avg CPU: {run['avg_cpu_percent']:.2f}%
- Max CPU: {run['max_cpu_percent']:.2f}%
- Avg Memory: {run['avg_memory_mb']:.2f} MB
- Max Memory: {run['max_memory_mb']:.2f} MB
- Vector Store Size: {run['vector_store_size_mb']:.2f} MB
"""
    
    # Analysis and conclusions
    perf_impact = "minimal" if abs(analysis["comparison"]["elapsed_time_diff_percent"]) < 5 else \
                  "moderate" if abs(analysis["comparison"]["elapsed_time_diff_percent"]) < 15 else "significant"
    
    report += f"""
## Analysis and Conclusions

The benchmark results show that MUS-based pruning has a **{perf_impact}** impact on overall system performance.

### Performance Impact
- Execution time: {analysis["comparison"]["elapsed_time_diff_percent"]:.2f}% {'increase' if analysis["comparison"]["elapsed_time_diff_percent"] > 0 else 'decrease'}
- CPU usage: {analysis["comparison"]["cpu_usage_diff_percent"]:.2f}% {'increase' if analysis["comparison"]["cpu_usage_diff_percent"] > 0 else 'decrease'}
- Memory usage: {analysis["comparison"]["memory_usage_diff_percent"]:.2f}% {'increase' if analysis["comparison"]["memory_usage_diff_percent"] > 0 else 'decrease'}

### Recommendations

"""
    
    # Add recommendations based on results
    if analysis["comparison"]["elapsed_time_diff_percent"] > 15:
        report += "- Consider optimizing the MUS calculation for better performance.\n"
        report += "- Increasing the check interval for MUS pruning might reduce the performance impact.\n"
    
    if analysis["comparison"]["vector_store_size_diff_percent"] < -10:
        report += "- MUS pruning effectively reduces storage size, which may offset performance costs.\n"
    
    report += """
### Further Investigation

- Measure the impact on memory retrieval quality (not just performance).
- Test with longer simulation runs to observe long-term effects.
- Evaluate different MUS threshold values for optimal balance.
"""
    
    return report

def main():
    """Main function to run the benchmark."""
    parser = argparse.ArgumentParser(description="Performance benchmark for MUS pruning")
    parser.add_argument("--scenario", choices=["baseline", "mus_enabled", "both"], 
                        default="both", help="Benchmark scenario to run")
    parser.add_argument("--agents", type=int, default=6, 
                        help="Number of agents in the simulation")
    parser.add_argument("--steps", type=int, default=500, 
                        help="Number of simulation steps per run")
    parser.add_argument("--runs", type=int, default=3, 
                        help="Number of benchmark runs per scenario")
    
    args = parser.parse_args()
    
    logger.info(f"Starting benchmark with configuration:")
    logger.info(f"  Scenario: {args.scenario}")
    logger.info(f"  Agents: {args.agents}")
    logger.info(f"  Steps: {args.steps}")
    logger.info(f"  Runs: {args.runs}")
    
    baseline_results = []
    mus_results = []
    
    # Run the appropriate benchmarks
    if args.scenario in ["baseline", "both"]:
        baseline_results = run_benchmark(
            scenario="baseline",
            num_agents=args.agents,
            steps=args.steps,
            runs=args.runs
        )
        
        # Save raw baseline results
        with open("benchmarks/baseline_results.json", "w") as f:
            json.dump(baseline_results, f, indent=2)
    
    if args.scenario in ["mus_enabled", "both"]:
        mus_results = run_benchmark(
            scenario="mus_enabled",
            num_agents=args.agents,
            steps=args.steps,
            runs=args.runs
        )
        
        # Save raw MUS results
        with open("benchmarks/mus_results.json", "w") as f:
            json.dump(mus_results, f, indent=2)
    
    # Generate analysis and report if we have both sets of results
    if baseline_results and mus_results:
        analysis = analyze_results(baseline_results, mus_results)
        
        # Save analysis
        with open("benchmarks/analysis.json", "w") as f:
            json.dump(analysis, f, indent=2)
        
        # Generate and save report
        report = generate_report(baseline_results, mus_results, analysis)
        report_path = "benchmarks/mus_pruning_performance_report.md"
        
        with open(report_path, "w") as f:
            f.write(report)
        
        logger.info(f"Benchmark report saved to {report_path}")
    
    logger.info("Benchmark completed")

if __name__ == "__main__":
    main() 