#!/usr/bin/env python
"""
Utilities for mocking LLM responses in tests.
"""

import sys
import os
import logging
import functools
from typing import Dict, Any, Optional
from contextlib import contextmanager

# Add project root to the path
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "../.."))
sys.path.insert(0, project_root)

from src.infra.llm_client import enable_mock_mode, is_ollama_available

logger = logging.getLogger(__name__)

class MockLLM:
    """
    Context manager for mocking LLM responses in tests.
    
    Example:
        with MockLLM():
            # LLM calls within this block will use mock responses
            result = generate_response("Hello")
    
    Or to customize mock responses:
        with MockLLM({
            "default": "Custom response",
            "AgentActionOutput": {
                "thought": "Mocked thought",
                "action_intent": "continue_collaboration",
                "message_content": "Mocked message"
            },
            "sentiment_analysis": "positive"
        }):
            # Use with custom responses
    """
    
    def __init__(self, mock_responses: Optional[Dict[str, Any]] = None):
        """
        Initialize the mock LLM context manager.
        
        Args:
            mock_responses: Dictionary of custom mock responses for different contexts
        """
        self.mock_responses = mock_responses
        self.was_enabled = False
    
    def __enter__(self):
        """Enable mock mode when entering the context."""
        from src.infra.llm_client import is_mock_mode_enabled
        self.was_enabled = is_mock_mode_enabled()
        enable_mock_mode(True, self.mock_responses)
        logger.debug("MockLLM: Enabled mock mode for LLM client")
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Restore previous mock mode state when exiting the context."""
        enable_mock_mode(self.was_enabled)
        logger.debug("MockLLM: Restored previous mock mode setting")

def requires_ollama(test_func):
    """
    Decorator to skip tests that require Ollama if Ollama is not available.
    
    Example:
        @requires_ollama
        def test_function_that_needs_ollama():
            # Test code that requires Ollama
    """
    @functools.wraps(test_func)
    def wrapper(*args, **kwargs):
        if not is_ollama_available():
            import unittest
            raise unittest.SkipTest("Ollama is not available")
        return test_func(*args, **kwargs)
    return wrapper 