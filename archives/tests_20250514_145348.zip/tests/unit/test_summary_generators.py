import unittest # Import unittest
import sys
import os
from unittest.mock import MagicMock, patch

# Add project root
# Base class for summary generator tests
@patch('src.infra.llm_client.generate_response')
class BaseSummaryTest(unittest.TestCase):

    def setUp(self, mock_generate_response):
        """Set up mocks common to all summary tests"""
        # Configure the global mock passed by @patch
        mock_generate_response.return_value = "Mocked summary content."
        self.mock_llm_client = MagicMock() 