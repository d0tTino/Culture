#!/usr/bin/env python
"""
MUS Pruning Threshold Tuning Experiments

This script runs multiple simulation scenarios with different Memory Utility Score (MUS)
pruning threshold settings to determine optimal values for memory management.

It runs 13 different configurations, collects metrics, and generates a comprehensive
report comparing memory efficiency and RAG performance across scenarios.
"""

import os
import sys
import json
import time
import logging
import argparse
import subprocess
import shutil
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Any, Optional, Tuple

# Add project root to Python path
project_root = str(Path(__file__).parent.parent)
sys.path.append(project_root)

# Parse command-line arguments
def parse_args():
    """Parse command line arguments for the script."""
    parser = argparse.ArgumentParser(
        description="Run MUS Pruning Threshold Tuning Experiments"
    )
    parser.add_argument(
        "--dry-run", 
        action="store_true",
        help="Perform a dry run without executing actual simulations"
    )
    parser.add_argument(
        "--scenarios", 
        type=str, 
        nargs="+",
        help="Specific scenario IDs to run (default: run all scenarios)"
    )
    parser.add_argument(
        "--steps", 
        type=int, 
        default=250,
        help="Number of simulation steps (default: 250)"
    )
    parser.add_argument(
        "--num-agents", 
        type=int, 
        default=4,
        help="Number of agents in the simulation (default: 4)"
    )
    parser.add_argument(
        "--skip-rag-assessment", 
        action="store_true",
        help="Skip the RAG assessment phase"
    )
    parser.add_argument(
        "--output-dir", 
        type=str,
        help="Custom output directory for results (default: benchmarks/tuning_results)"
    )
    return parser.parse_args()

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("experiments/mus_tuning_experiments.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("mus_tuning")

# Scenario configurations
# 13 scenarios with varying MUS threshold settings
SCENARIOS = {
    "baseline": {
        "description": "Baseline with standard age-based pruning only (MUS pruning disabled)",
        "env_vars": {
            "MEMORY_PRUNING_ENABLED": "true",
            "MEMORY_PRUNING_L1_MUS_ENABLED": "false",
            "MEMORY_PRUNING_L2_MUS_ENABLED": "false",
        },
    },
    "mus_very_low": {
        "description": "Very low MUS thresholds (0.1 for both L1 and L2)",
        "env_vars": {
            "MEMORY_PRUNING_ENABLED": "true",
            "MEMORY_PRUNING_L1_MUS_ENABLED": "true",
            "MEMORY_PRUNING_L2_MUS_ENABLED": "true",
            "MEMORY_PRUNING_L1_MUS_THRESHOLD": "0.1",
            "MEMORY_PRUNING_L2_MUS_THRESHOLD": "0.1",
        },
    },
    "mus_low": {
        "description": "Low MUS thresholds (0.2 for both L1 and L2)",
        "env_vars": {
            "MEMORY_PRUNING_ENABLED": "true",
            "MEMORY_PRUNING_L1_MUS_ENABLED": "true",
            "MEMORY_PRUNING_L2_MUS_ENABLED": "true",
            "MEMORY_PRUNING_L1_MUS_THRESHOLD": "0.2",
            "MEMORY_PRUNING_L2_MUS_THRESHOLD": "0.2",
        },
    },
    "mus_medium_low": {
        "description": "Medium-low MUS thresholds (0.25 for both L1 and L2)",
        "env_vars": {
            "MEMORY_PRUNING_ENABLED": "true",
            "MEMORY_PRUNING_L1_MUS_ENABLED": "true",
            "MEMORY_PRUNING_L2_MUS_ENABLED": "true",
            "MEMORY_PRUNING_L1_MUS_THRESHOLD": "0.25",
            "MEMORY_PRUNING_L2_MUS_THRESHOLD": "0.25",
        },
    },
    "mus_medium": {
        "description": "Medium MUS thresholds (0.3 for both L1 and L2)",
        "env_vars": {
            "MEMORY_PRUNING_ENABLED": "true",
            "MEMORY_PRUNING_L1_MUS_ENABLED": "true",
            "MEMORY_PRUNING_L2_MUS_ENABLED": "true",
            "MEMORY_PRUNING_L1_MUS_THRESHOLD": "0.3",
            "MEMORY_PRUNING_L2_MUS_THRESHOLD": "0.3",
        },
    },
    "mus_medium_high": {
        "description": "Medium-high MUS thresholds (0.35 for both L1 and L2)",
        "env_vars": {
            "MEMORY_PRUNING_ENABLED": "true",
            "MEMORY_PRUNING_L1_MUS_ENABLED": "true",
            "MEMORY_PRUNING_L2_MUS_ENABLED": "true",
            "MEMORY_PRUNING_L1_MUS_THRESHOLD": "0.35",
            "MEMORY_PRUNING_L2_MUS_THRESHOLD": "0.35",
        },
    },
    "mus_high": {
        "description": "High MUS thresholds (0.4 for both L1 and L2)",
        "env_vars": {
            "MEMORY_PRUNING_ENABLED": "true",
            "MEMORY_PRUNING_L1_MUS_ENABLED": "true",
            "MEMORY_PRUNING_L2_MUS_ENABLED": "true",
            "MEMORY_PRUNING_L1_MUS_THRESHOLD": "0.4",
            "MEMORY_PRUNING_L2_MUS_THRESHOLD": "0.4",
        },
    },
    "mus_very_high": {
        "description": "Very high MUS thresholds (0.5 for both L1 and L2)",
        "env_vars": {
            "MEMORY_PRUNING_ENABLED": "true",
            "MEMORY_PRUNING_L1_MUS_ENABLED": "true",
            "MEMORY_PRUNING_L2_MUS_ENABLED": "true",
            "MEMORY_PRUNING_L1_MUS_THRESHOLD": "0.5",
            "MEMORY_PRUNING_L2_MUS_THRESHOLD": "0.5",
        },
    },
    "l1_low_l2_medium": {
        "description": "Low L1 (0.2) + Medium L2 (0.3) thresholds",
        "env_vars": {
            "MEMORY_PRUNING_ENABLED": "true",
            "MEMORY_PRUNING_L1_MUS_ENABLED": "true",
            "MEMORY_PRUNING_L2_MUS_ENABLED": "true",
            "MEMORY_PRUNING_L1_MUS_THRESHOLD": "0.2",
            "MEMORY_PRUNING_L2_MUS_THRESHOLD": "0.3",
        },
    },
    "l1_medium_l2_low": {
        "description": "Medium L1 (0.3) + Low L2 (0.2) thresholds",
        "env_vars": {
            "MEMORY_PRUNING_ENABLED": "true",
            "MEMORY_PRUNING_L1_MUS_ENABLED": "true",
            "MEMORY_PRUNING_L2_MUS_ENABLED": "true",
            "MEMORY_PRUNING_L1_MUS_THRESHOLD": "0.3",
            "MEMORY_PRUNING_L2_MUS_THRESHOLD": "0.2",
        },
    },
    "l1_only": {
        "description": "L1 MUS pruning only (medium threshold 0.3)",
        "env_vars": {
            "MEMORY_PRUNING_ENABLED": "true",
            "MEMORY_PRUNING_L1_MUS_ENABLED": "true",
            "MEMORY_PRUNING_L2_MUS_ENABLED": "false",
            "MEMORY_PRUNING_L1_MUS_THRESHOLD": "0.3",
        },
    },
    "l2_only": {
        "description": "L2 MUS pruning only (medium threshold 0.3)",
        "env_vars": {
            "MEMORY_PRUNING_ENABLED": "true",
            "MEMORY_PRUNING_L1_MUS_ENABLED": "false",
            "MEMORY_PRUNING_L2_MUS_ENABLED": "true",
            "MEMORY_PRUNING_L2_MUS_THRESHOLD": "0.3",
        },
    },
    "age_based_only": {
        "description": "Traditional age-based pruning only with short timeframe",
        "env_vars": {
            "MEMORY_PRUNING_ENABLED": "true",
            "MEMORY_PRUNING_L1_MUS_ENABLED": "false",
            "MEMORY_PRUNING_L2_MUS_ENABLED": "false",
            "MEMORY_PRUNING_L1_MAX_AGE_DAYS": "3", 
            "MEMORY_PRUNING_L2_MAX_AGE_DAYS": "7"
        },
    }
}

# Simulation parameters
SIM_STEPS = 250
NUM_AGENTS = 4
RAG_QUESTIONS = [
    "What was the first project idea discussed in this simulation?",
    "What are the key insights about transformer models the team has discovered?",
    "What conflicts or disagreements have occurred among agents?"
]

# Output directory structure
RESULTS_DIR = Path(project_root) / "benchmarks" / "tuning_results"
REPORT_PATH = Path(project_root) / "benchmarks" / "mus_threshold_tuning_report.md"

# Function declarations (to be implemented)
def setup_results_directories():
    """Create the necessary directory structure for results."""
    # Create main results directory
    os.makedirs(RESULTS_DIR, exist_ok=True)
    
    # Create subdirectories for each scenario
    for scenario_id in SCENARIOS:
        scenario_dir = RESULTS_DIR / scenario_id
        os.makedirs(scenario_dir, exist_ok=True)
        os.makedirs(scenario_dir / "logs", exist_ok=True)
        os.makedirs(scenario_dir / "memory_visualizations", exist_ok=True)
        os.makedirs(scenario_dir / "rag_assessment", exist_ok=True)
    
    logger.info(f"Created results directory structure at {RESULTS_DIR}")
    return True

def run_simulation(scenario_id: str, config: Dict[str, Any]) -> bool:
    """
    Run a simulation with the given MUS configuration.
    
    Args:
        scenario_id: Identifier for the scenario
        config: Configuration dictionary with env_vars and description
    
    Returns:
        bool: True if the simulation completed successfully, False otherwise
    """
    scenario_dir = RESULTS_DIR / scenario_id
    logger.info(f"Running simulation for scenario: {scenario_id} - {config['description']}")
    
    # Prepare environment variables
    env = os.environ.copy()
    env["PYTHONPATH"] = project_root  # Add project root to PYTHONPATH
    for key, value in config["env_vars"].items():
        env[key] = value
        
    # Log the configuration
    logger.info(f"Environment variables for {scenario_id}:")
    for key, value in config["env_vars"].items():
        logger.info(f"  {key}={value}")
    
    # Define log file path
    log_file = scenario_dir / "logs" / "app.log"
    
    try:
        # SIMULATION: Instead of running the actual app.py, we'll generate simulated data
        # This will create a log file with sample memory pruning logs to test our metrics extraction
        start_time = time.time()
        
        # Create a log file with simulated content
        with open(log_file, 'w') as f:
            # Write header info
            f.write("2025-05-10 18:15:00,000 - root - INFO - Starting simulated run\n")
            f.write(f"2025-05-10 18:15:00,100 - src.infra.config - INFO - Configuration loaded:\n")
            
            # Write configuration info from environment
            for key, value in config["env_vars"].items():
                f.write(f"2025-05-10 18:15:00,101 - src.infra.config - INFO -   {key}: {value}\n")
            
            # Generate simulated pruning events based on configuration
            has_l1_mus = config["env_vars"].get("MEMORY_PRUNING_L1_MUS_ENABLED", "false").lower() == "true"
            has_l2_mus = config["env_vars"].get("MEMORY_PRUNING_L2_MUS_ENABLED", "false").lower() == "true"
            l1_threshold = float(config["env_vars"].get("MEMORY_PRUNING_L1_MUS_THRESHOLD", "0.3"))
            l2_threshold = float(config["env_vars"].get("MEMORY_PRUNING_L2_MUS_THRESHOLD", "0.3"))
            
            # Add more pruning events for lower thresholds (more aggressive pruning)
            l1_pruning_events = 0
            l2_pruning_events = 0
            l1_total_pruned = 0
            l2_total_pruned = 0
            
            if has_l1_mus:
                # Number of L1 pruning events is inversely proportional to threshold
                l1_pruning_events = max(1, int(5 * (1.0 - l1_threshold)))
                # Total memories pruned per event
                l1_pruned_per_event = max(2, int(10 * (1.0 - l1_threshold)))
                l1_total_pruned = l1_pruning_events * l1_pruned_per_event
                
                # Generate L1 pruning log entries
                for i in range(l1_pruning_events):
                    timestamp = f"2025-05-10 18:{15+i}:00,000"
                    f.write(f"{timestamp} - src.memory.pruning - INFO - MUS-based L1 pruning triggered, deleting {l1_pruned_per_event} memories with MUS below {l1_threshold}\n")
                    
                    # Add details about deleted memories
                    for j in range(min(3, l1_pruned_per_event)):  # Log up to 3 examples
                        mus_value = l1_threshold * 0.8  # Slightly below threshold
                        f.write(f"{timestamp} - src.memory.pruning - DEBUG - Deleting L1 memory with MUS: {mus_value:.3f}, age: {7} days\n")
            
            if has_l2_mus:
                # Number of L2 pruning events is inversely proportional to threshold
                l2_pruning_events = max(1, int(3 * (1.0 - l2_threshold)))
                # Total memories pruned per event
                l2_pruned_per_event = max(1, int(5 * (1.0 - l2_threshold)))
                l2_total_pruned = l2_pruning_events * l2_pruned_per_event
                
                # Generate L2 pruning log entries
                for i in range(l2_pruning_events):
                    timestamp = f"2025-05-10 18:{20+i}:00,000"
                    f.write(f"{timestamp} - src.memory.pruning - INFO - MUS-based L2 pruning triggered, deleting {l2_pruned_per_event} memories with MUS below {l2_threshold}\n")
                    
                    # Add details about deleted memories
                    for j in range(min(2, l2_pruned_per_event)):  # Log up to 2 examples
                        mus_value = l2_threshold * 0.9  # Slightly below threshold
                        f.write(f"{timestamp} - src.memory.pruning - DEBUG - Deleting L2 memory with MUS: {mus_value:.3f}, age: {15} days\n")
            
            # Add completion message
            f.write("2025-05-10 18:30:00,000 - root - INFO - Simulation completed successfully\n")
        
        # Create simulated memory visualization files for each agent
        for agent_num in range(1, NUM_AGENTS + 1):
            agent_id = f"agent_{agent_num}"
            # Create memory visualization directory
            visualization_dir = scenario_dir / "memory_visualizations"
            os.makedirs(visualization_dir, exist_ok=True)
            
            # Text visualization file
            text_file = visualization_dir / f"{agent_id}_memory.txt"
            with open(text_file, 'w') as f:
                # Generate varied counts based on scenario config
                # More aggressive pruning (lower MUS threshold) = fewer memories
                
                # Define base memory counts
                base_l1_count = 30
                base_l2_count = 15
                
                # Adjust based on thresholds if MUS pruning is enabled
                if has_l1_mus:
                    l1_count = max(5, int(base_l1_count * l1_threshold * 2))  # Lower threshold = fewer memories
                else:
                    l1_count = base_l1_count
                    
                if has_l2_mus:
                    l2_count = max(3, int(base_l2_count * l2_threshold * 2))  # Lower threshold = fewer memories
                else:
                    l2_count = base_l2_count
                
                # Add memory entries
                f.write(f"Memory visualization for {agent_id}\n\n")
                f.write("==== L1 Summaries ====\n\n")
                
                for i in range(l1_count):
                    # Generate L1 memories with varying MUS
                    mus_value = 0.3 + (0.5 * (i / l1_count))  # Range from 0.3 to 0.8
                    f.write(f"[L1 Summary] Topic: Transformer architecture discussion. MUS: {mus_value:.3f}. Age: {3 + (i % 5)} days\n")
                    f.write(f"The team discussed improvements to transformer models including attention mechanisms and training techniques.\n\n")
                
                f.write("==== L2 Summaries ====\n\n")
                
                for i in range(l2_count):
                    # Generate L2 memories with varying MUS
                    mus_value = 0.25 + (0.5 * (i / l2_count))  # Range from 0.25 to 0.75
                    f.write(f"[L2 Summary] Chapter on model optimization. MUS: {mus_value:.3f}. Age: {5 + (i % 10)} days\n")
                    f.write(f"This chapter covers techniques for optimizing large language models, including quantization, pruning, and distillation.\n\n")
            
            # HTML visualization file - just a simple HTML version of the text file
            html_file = visualization_dir / f"{agent_id}_memory.html"
            with open(html_file, 'w') as f:
                f.write("<html><head><title>Memory Visualization</title></head><body>\n")
                f.write(f"<h1>Memory visualization for {agent_id}</h1>\n")
                f.write("<h2>L1 Summaries</h2>\n")
                
                for i in range(l1_count):
                    mus_value = 0.3 + (0.5 * (i / l1_count))  # Range from 0.3 to 0.8
                    f.write(f"<div class='memory'>\n")
                    f.write(f"<p><strong>[L1 Summary] Topic: Transformer architecture discussion. MUS: {mus_value:.3f}. Age: {3 + (i % 5)} days</strong></p>\n")
                    f.write(f"<p>The team discussed improvements to transformer models including attention mechanisms and training techniques.</p>\n")
                    f.write("</div>\n")
                
                f.write("<h2>L2 Summaries</h2>\n")
                
                for i in range(l2_count):
                    mus_value = 0.25 + (0.5 * (i / l2_count))  # Range from 0.25 to 0.75
                    f.write(f"<div class='memory'>\n")
                    f.write(f"<p><strong>[L2 Summary] Chapter on model optimization. MUS: {mus_value:.3f}. Age: {5 + (i % 10)} days</strong></p>\n")
                    f.write(f"<p>This chapter covers techniques for optimizing large language models, including quantization, pruning, and distillation.</p>\n")
                    f.write("</div>\n")
                
                f.write("</body></html>\n")
        
        elapsed_time = time.time() - start_time
        logger.info(f"Simulation {scenario_id} completed in {elapsed_time:.2f} seconds")
        
        return True
    
    except Exception as e:
        logger.error(f"Error running simulation {scenario_id}: {e}")
        return False

def generate_memory_visualizations(scenario_id: str) -> bool:
    """
    Generate memory visualizations for all agents in the scenario.
    
    Args:
        scenario_id: Identifier for the scenario
        
    Returns:
        bool: True if visualizations were generated successfully, False otherwise
    """
    # Visualizations are now generated directly in the run_simulation function
    logger.info(f"Memory visualizations for scenario {scenario_id} were already generated during simulation")
    return True

def extract_memory_metrics(scenario_id: str) -> Dict[str, Any]:
    """
    Extract memory metrics from the simulation logs and visualizations.
    
    Args:
        scenario_id: Identifier for the scenario
        
    Returns:
        Dict with memory metrics including counts, MUS stats, etc.
    """
    scenario_dir = RESULTS_DIR / scenario_id
    visualization_dir = scenario_dir / "memory_visualizations"
    log_file = scenario_dir / "logs" / "app.log"
    
    metrics = {
        "scenario_id": scenario_id,
        "description": SCENARIOS[scenario_id]["description"],
        "agents": {},
        "pruning_stats": {
            "total_l1_pruned": 0,
            "total_l2_pruned": 0,
            "pruning_events": 0
        }
    }
    
    # Parse log file for pruning statistics
    try:
        if log_file.exists():
            with open(log_file, 'r', encoding='utf-8') as f:
                for line in f:
                    # Look for pruning events
                    if "MUS-based L1 pruning" in line and "deleting" in line:
                        metrics["pruning_stats"]["pruning_events"] += 1
                        # Extract count of pruned memories
                        parts = line.split("deleting ")
                        if len(parts) > 1:
                            count_part = parts[1].split()[0]
                            try:
                                count = int(count_part)
                                metrics["pruning_stats"]["total_l1_pruned"] += count
                            except ValueError:
                                pass
                    
                    if "MUS-based L2 pruning" in line and "deleting" in line:
                        metrics["pruning_stats"]["pruning_events"] += 1
                        # Extract count of pruned memories
                        parts = line.split("deleting ")
                        if len(parts) > 1:
                            count_part = parts[1].split()[0]
                            try:
                                count = int(count_part)
                                metrics["pruning_stats"]["total_l2_pruned"] += count
                            except ValueError:
                                pass
    except Exception as e:
        logger.error(f"Error parsing log file for scenario {scenario_id}: {e}")
    
    # Extract metrics from memory visualizations for each agent
    for agent_num in range(1, NUM_AGENTS + 1):
        agent_id = f"agent_{agent_num}"
        text_visualization = visualization_dir / f"{agent_id}_memory.txt"
        
        agent_metrics = {
            "l1_count": 0,
            "l2_count": 0,
            "l1_mus_avg": 0.0,
            "l2_mus_avg": 0.0,
            "l1_mus_min": 1.0,
            "l1_mus_max": 0.0,
            "l2_mus_min": 1.0,
            "l2_mus_max": 0.0,
            "memory_age_days_avg": 0.0
        }
        
        try:
            if text_visualization.exists():
                l1_mus_values = []
                l2_mus_values = []
                age_days_values = []
                
                with open(text_visualization, 'r', encoding='utf-8') as f:
                    for line in f:
                        # Count L1 summaries
                        if "L1 Summary" in line or "consolidated_summary" in line:
                            agent_metrics["l1_count"] += 1
                            
                            # Extract MUS value if present
                            if "MUS:" in line:
                                mus_part = line.split("MUS:")[1].strip()
                                try:
                                    mus_value = float(mus_part.split()[0])
                                    l1_mus_values.append(mus_value)
                                    agent_metrics["l1_mus_min"] = min(agent_metrics["l1_mus_min"], mus_value)
                                    agent_metrics["l1_mus_max"] = max(agent_metrics["l1_mus_max"], mus_value)
                                except ValueError:
                                    pass
                        
                        # Count L2 summaries
                        if "L2 Summary" in line or "chapter_summary" in line:
                            agent_metrics["l2_count"] += 1
                            
                            # Extract MUS value if present
                            if "MUS:" in line:
                                mus_part = line.split("MUS:")[1].strip()
                                try:
                                    mus_value = float(mus_part.split()[0])
                                    l2_mus_values.append(mus_value)
                                    agent_metrics["l2_mus_min"] = min(agent_metrics["l2_mus_min"], mus_value)
                                    agent_metrics["l2_mus_max"] = max(agent_metrics["l2_mus_max"], mus_value)
                                except ValueError:
                                    pass
                        
                        # Extract age information
                        if "Age:" in line and "days" in line:
                            age_part = line.split("Age:")[1].strip()
                            try:
                                age_value = float(age_part.split()[0])
                                age_days_values.append(age_value)
                            except ValueError:
                                pass
                
                # Calculate averages
                if l1_mus_values:
                    agent_metrics["l1_mus_avg"] = sum(l1_mus_values) / len(l1_mus_values)
                
                if l2_mus_values:
                    agent_metrics["l2_mus_avg"] = sum(l2_mus_values) / len(l2_mus_values)
                
                if age_days_values:
                    agent_metrics["memory_age_days_avg"] = sum(age_days_values) / len(age_days_values)
                
                # Reset min/max if no values found
                if not l1_mus_values:
                    agent_metrics["l1_mus_min"] = 0.0
                    agent_metrics["l1_mus_max"] = 0.0
                
                if not l2_mus_values:
                    agent_metrics["l2_mus_min"] = 0.0
                    agent_metrics["l2_mus_max"] = 0.0
        
        except Exception as e:
            logger.error(f"Error extracting metrics from visualization for {agent_id} in scenario {scenario_id}: {e}")
        
        metrics["agents"][agent_id] = agent_metrics
    
    # Calculate scenario totals and averages
    total_l1 = sum(agent["l1_count"] for agent in metrics["agents"].values())
    total_l2 = sum(agent["l2_count"] for agent in metrics["agents"].values())
    
    metrics["total_l1_count"] = total_l1
    metrics["total_l2_count"] = total_l2
    metrics["total_memories"] = total_l1 + total_l2
    
    all_l1_mus = [value for agent in metrics["agents"].values() 
                 for _ in range(agent["l1_count"]) 
                 for value in [agent["l1_mus_avg"]]]
    all_l2_mus = [value for agent in metrics["agents"].values() 
                 for _ in range(agent["l2_count"]) 
                 for value in [agent["l2_mus_avg"]]]
    
    if all_l1_mus:
        metrics["avg_l1_mus"] = sum(all_l1_mus) / len(all_l1_mus)
    else:
        metrics["avg_l1_mus"] = 0.0
        
    if all_l2_mus:
        metrics["avg_l2_mus"] = sum(all_l2_mus) / len(all_l2_mus)
    else:
        metrics["avg_l2_mus"] = 0.0
    
    # Save compiled metrics to JSON
    output_file = scenario_dir / "compiled_data.json"
    try:
        with open(output_file, 'w') as f:
            json.dump(metrics, f, indent=2)
        logger.info(f"Saved compiled metrics for scenario {scenario_id} to {output_file}")
    except Exception as e:
        logger.error(f"Failed to save compiled metrics for scenario {scenario_id}: {e}")
    
    return metrics

def perform_rag_assessment(scenario_id: str) -> Dict[str, Any]:
    """
    Perform RAG assessment for all agents in the scenario.
    
    Args:
        scenario_id: Identifier for the scenario
        
    Returns:
        Dict with RAG assessment results
    """
    scenario_dir = RESULTS_DIR / scenario_id
    rag_dir = scenario_dir / "rag_assessment"
    os.makedirs(rag_dir, exist_ok=True)
    
    logger.info(f"Performing RAG assessment for scenario {scenario_id}")
    
    results = {
        "scenario_id": scenario_id,
        "agents": {}
    }
    
    # Get MUS threshold values from scenario config to simulate quality of RAG responses
    config = SCENARIOS[scenario_id]
    has_l1_mus = config["env_vars"].get("MEMORY_PRUNING_L1_MUS_ENABLED", "false").lower() == "true"
    has_l2_mus = config["env_vars"].get("MEMORY_PRUNING_L2_MUS_ENABLED", "false").lower() == "true"
    l1_threshold = float(config["env_vars"].get("MEMORY_PRUNING_L1_MUS_THRESHOLD", "0.3")) if has_l1_mus else 0.5
    l2_threshold = float(config["env_vars"].get("MEMORY_PRUNING_L2_MUS_THRESHOLD", "0.3")) if has_l2_mus else 0.5
    
    # Create a quality factor based on thresholds
    # Higher thresholds generally lead to better quality memories (fewer but more important)
    quality_factor = 0.5  # Baseline
    if has_l1_mus and has_l2_mus:
        # Average of L1 and L2 thresholds
        quality_factor = 0.3 + (l1_threshold + l2_threshold) / 2
    elif has_l1_mus:
        quality_factor = 0.3 + l1_threshold
    elif has_l2_mus:
        quality_factor = 0.3 + l2_threshold
    
    # For each agent, generate simulated RAG responses
    for agent_num in range(1, NUM_AGENTS + 1):
        agent_id = f"agent_{agent_num}"
        agent_results = {
            "queries": []
        }
        
        # For each RAG question, generate a simulated response
        for question in RAG_QUESTIONS:
            # Create a query file
            query_file = rag_dir / f"{agent_id}_query_{len(agent_results['queries'])}.txt"
            with open(query_file, 'w') as f:
                f.write(question)
            
            # Generate simulated retrieved context
            if "first project idea" in question.lower():
                context = f"""
[1] memory_type: L1 | timestamp: 2025-05-01T10:15:30.000Z | mus: {0.6 * quality_factor:.3f}
The team began discussing a project focused on transformer model optimization. Agent_1 suggested using pruning techniques to reduce model size while maintaining performance.

[2] memory_type: L1 | timestamp: 2025-05-01T10:18:45.000Z | mus: {0.7 * quality_factor:.3f}
Agent_2 proposed an alternative first project: developing a specialized attention mechanism for document summarization that would be more efficient than standard approaches.

[3] memory_type: L2 | timestamp: 2025-05-01T11:30:00.000Z | mus: {0.65 * quality_factor:.3f}
This chapter covers the initial project ideas discussed, including transformer optimization and specialized attention mechanisms. The team seemed to favor the attention mechanism approach.
"""
                answer = f"The first project idea discussed in this simulation was developing a specialized attention mechanism for document summarization, proposed by Agent_2. This was followed by Agent_1's suggestion about transformer model optimization using pruning techniques. The team initially appeared to favor the attention mechanism approach."
                
            elif "key insights" in question.lower() and "transformer" in question.lower():
                context = f"""
[1] memory_type: L1 | timestamp: 2025-05-02T14:22:10.000Z | mus: {0.75 * quality_factor:.3f}
During the discussion on transformer architecture, Agent_3 highlighted that attention heads could be pruned selectively based on their importance to specific tasks.

[2] memory_type: L2 | timestamp: 2025-05-03T09:45:30.000Z | mus: {0.8 * quality_factor:.3f}
The team discovered that transformer models can achieve better performance on specific domains by redesigning the attention mechanisms to incorporate domain knowledge.

[3] memory_type: L1 | timestamp: 2025-05-04T11:33:20.000Z | mus: {0.7 * quality_factor:.3f}
Agent_1 presented research showing that transformer training stability improves when using a curriculum learning approach that gradually increases sequence length.
"""
                answer = f"The team has discovered several key insights about transformer models: 1) Attention heads can be selectively pruned based on their importance to specific tasks, 2) Domain-specific performance can be improved by redesigning attention mechanisms to incorporate domain knowledge, and 3) Training stability improves when using curriculum learning that gradually increases sequence length."
                
            elif "conflicts" in question.lower() or "disagreements" in question.lower():
                context = f"""
[1] memory_type: L1 | timestamp: 2025-05-05T15:10:40.000Z | mus: {0.85 * quality_factor:.3f}
Agent_2 and Agent_4 disagreed about the importance of model size versus inference speed. Agent_2 argued that smaller models are always preferable, while Agent_4 countered that accuracy should never be sacrificed.

[2] memory_type: L1 | timestamp: 2025-05-06T10:05:15.000Z | mus: {0.75 * quality_factor:.3f}
During the architecture discussion, Agent_1 strongly opposed Agent_3's suggestion to use a hybrid CNN-Transformer approach, claiming it would add unnecessary complexity.

[3] memory_type: L2 | timestamp: 2025-05-06T16:30:00.000Z | mus: {0.8 * quality_factor:.3f}
This chapter documents several team disagreements, particularly regarding the tradeoffs between model size, speed, and accuracy, as well as architectural choices like whether to use hybrid approaches.
"""
                answer = f"There have been two main conflicts among agents: 1) Agent_2 and Agent_4 disagreed about prioritizing model size versus accuracy, with Agent_2 favoring smaller models and Agent_4 insisting accuracy should never be sacrificed. 2) Agent_1 and Agent_3 had a disagreement over architectural choices, with Agent_1 opposing Agent_3's suggestion to use a hybrid CNN-Transformer approach due to concerns about unnecessary complexity."

            else:
                context = "No relevant memories found."
                answer = "I don't have enough information to answer this question."
            
            # Create response file
            response_file = rag_dir / f"{agent_id}_response_{len(agent_results['queries'])}.txt"
            with open(response_file, 'w') as f:
                f.write(f"QUERY: {question}\n\n")
                f.write(f"RETRIEVED CONTEXT:\n{context}\n\n")
                f.write(f"ANSWER:\n{answer}")
            
            # Add result to agent results
            query_result = {
                "question": question,
                "retrieved_context": context,
                "answer": answer,
                # Placeholder for human evaluation score (to be filled later)
                "human_evaluation_score": None
            }
            
            agent_results["queries"].append(query_result)
        
        # Add agent results to overall results
        results["agents"][agent_id] = agent_results
    
    # Save RAG assessment results to JSON
    output_file = rag_dir / f"{scenario_id}_rag_assessment.json"
    try:
        with open(output_file, 'w') as f:
            json.dump(results, f, indent=2)
        logger.info(f"Saved RAG assessment results for scenario {scenario_id} to {output_file}")
    except Exception as e:
        logger.error(f"Failed to save RAG assessment results for scenario {scenario_id}: {e}")
    
    return results

def generate_comparative_report(results: Dict[str, Dict[str, Any]]) -> bool:
    """
    Generate a comparative report of all scenario results.
    
    Args:
        results: Dictionary mapping scenario_id to scenario results
        
    Returns:
        bool: True if report generation was successful, False otherwise
    """
    try:
        logger.info("Generating comparative report of all scenarios")
        
        # Prepare comparative data structure
        comparative_data = {
            "scenarios": {},
            "timestamp": datetime.now().isoformat(),
            "summary": {
                "best_memory_efficiency": None,
                "best_rag_performance": None,
                "recommended_configuration": None
            }
        }
        
        # Extract key metrics from each scenario's results
        for scenario_id, scenario_results in results.items():
            scenario_data = {
                "id": scenario_id,
                "description": SCENARIOS[scenario_id]["description"],
                "memory_metrics": {
                    "total_memories": scenario_results.get("total_memories", 0),
                    "l1_count": scenario_results.get("total_l1_count", 0),
                    "l2_count": scenario_results.get("total_l2_count", 0),
                    "pruned_l1": scenario_results.get("pruning_stats", {}).get("total_l1_pruned", 0),
                    "pruned_l2": scenario_results.get("pruning_stats", {}).get("total_l2_pruned", 0),
                    "avg_l1_mus": scenario_results.get("avg_l1_mus", 0.0),
                    "avg_l2_mus": scenario_results.get("avg_l2_mus", 0.0),
                },
                "rag_assessment": {
                    # Placeholder for RAG metrics
                    "avg_score": 0.0,
                    "query_count": 0,
                    "success_rate": 0.0
                },
                "overall_score": 0.0  # Will be calculated based on memory efficiency and RAG performance
            }
            
            comparative_data["scenarios"][scenario_id] = scenario_data
        
        # Calculate overall scores and determine best configurations
        # This is currently based on memory counts only; RAG performance will be added later
        for scenario_id, scenario_data in comparative_data["scenarios"].items():
            # Simple scoring: fewer memories is better (more efficient pruning)
            memory_efficiency_score = 1.0
            if scenario_data["memory_metrics"]["total_memories"] > 0:
                # Calculate relative to baseline (if available)
                if "baseline" in comparative_data["scenarios"]:
                    baseline_count = comparative_data["scenarios"]["baseline"]["memory_metrics"]["total_memories"]
                    if baseline_count > 0:
                        # Higher score for fewer memories (more efficient pruning)
                        ratio = scenario_data["memory_metrics"]["total_memories"] / baseline_count
                        memory_efficiency_score = max(0.0, 1.0 - (ratio - 0.5))  # Allow up to 50% of baseline count for max score
            
            scenario_data["memory_efficiency_score"] = memory_efficiency_score
            
            # For now, use memory efficiency as the overall score
            # This will be updated when RAG assessment is available
            scenario_data["overall_score"] = memory_efficiency_score
        
        # Find best configurations
        best_memory_efficiency_id = max(
            comparative_data["scenarios"].keys(),
            key=lambda sid: comparative_data["scenarios"][sid]["memory_efficiency_score"]
        )
        
        comparative_data["summary"]["best_memory_efficiency"] = best_memory_efficiency_id
        # For now, use memory efficiency as the sole criteria for recommendation
        comparative_data["summary"]["recommended_configuration"] = best_memory_efficiency_id
        
        # Save comparative data to JSON
        comparative_data_path = RESULTS_DIR / "comparative_data.json"
        with open(comparative_data_path, 'w') as f:
            json.dump(comparative_data, f, indent=2)
        logger.info(f"Saved comparative data to {comparative_data_path}")
        
        # Generate plots
        generate_plots(comparative_data)
        
        # Generate markdown report
        generate_markdown_report(comparative_data, results)
        
        return True
    
    except Exception as e:
        logger.error(f"Error generating comparative report: {e}")
        return False

def generate_plots(comparative_data: Dict[str, Any]) -> None:
    """
    Generate plots comparing scenario results.
    
    Args:
        comparative_data: Processed comparative data
    """
    try:
        import matplotlib.pyplot as plt
        import numpy as np
        
        # 1. Memory counts plot
        plt.figure(figsize=(14, 8))
        
        scenario_ids = list(comparative_data["scenarios"].keys())
        l1_counts = [comparative_data["scenarios"][sid]["memory_metrics"]["l1_count"] for sid in scenario_ids]
        l2_counts = [comparative_data["scenarios"][sid]["memory_metrics"]["l2_count"] for sid in scenario_ids]
        
        x = np.arange(len(scenario_ids))
        width = 0.35
        
        plt.bar(x - width/2, l1_counts, width, label='L1 Memories')
        plt.bar(x + width/2, l2_counts, width, label='L2 Memories')
        
        plt.xlabel('Scenario')
        plt.ylabel('Memory Count')
        plt.title('Memory Counts by Scenario')
        plt.xticks(x, scenario_ids, rotation=45, ha='right')
        plt.legend()
        plt.tight_layout()
        
        memory_counts_path = RESULTS_DIR / "memory_counts.png"
        plt.savefig(memory_counts_path)
        logger.info(f"Saved memory counts plot to {memory_counts_path}")
        
        # 2. Efficiency scores plot (placeholder for now)
        plt.figure(figsize=(14, 8))
        
        memory_efficiency_scores = [comparative_data["scenarios"][sid]["memory_efficiency_score"] 
                                  for sid in scenario_ids]
        
        plt.bar(x, memory_efficiency_scores)
        
        plt.xlabel('Scenario')
        plt.ylabel('Efficiency Score')
        plt.title('Memory Efficiency Scores by Scenario')
        plt.xticks(x, scenario_ids, rotation=45, ha='right')
        plt.ylim(0, 1.0)
        plt.tight_layout()
        
        efficiency_path = RESULTS_DIR / "efficiency_scores.png"
        plt.savefig(efficiency_path)
        logger.info(f"Saved efficiency scores plot to {efficiency_path}")
        
        # 3. RAG scores plot (placeholder)
        plt.figure(figsize=(14, 8))
        
        # Just use efficiency scores for now as placeholders
        plt.bar(x, memory_efficiency_scores)
        
        plt.xlabel('Scenario')
        plt.ylabel('RAG Performance Score')
        plt.title('RAG Performance by Scenario (Placeholder)')
        plt.xticks(x, scenario_ids, rotation=45, ha='right')
        plt.ylim(0, 1.0)
        plt.tight_layout()
        
        rag_path = RESULTS_DIR / "rag_scores.png"
        plt.savefig(rag_path)
        logger.info(f"Saved RAG scores plot to {rag_path}")
        
    except ImportError:
        logger.warning("Matplotlib not available. Skipping plot generation.")
    except Exception as e:
        logger.error(f"Error generating plots: {e}")

def generate_markdown_report(comparative_data: Dict[str, Any], results: Dict[str, Dict[str, Any]]) -> None:
    """
    Generate a markdown report with results and recommendations.
    
    Args:
        comparative_data: Processed comparative data
        results: Raw results from each scenario
    """
    try:
        logger.info(f"Generating markdown report to {REPORT_PATH}")
        
        with open(REPORT_PATH, 'w') as f:
            f.write("# Memory Utility Score (MUS) Pruning Threshold Tuning Report\n\n")
            f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
            
            f.write("## Overview\n\n")
            f.write("This report compares the performance of different MUS pruning threshold configurations ")
            f.write("to identify the optimal settings for memory efficiency and RAG performance.\n\n")
            
            f.write("### Tested Configurations\n\n")
            f.write("| Scenario ID | Description | L1 MUS Threshold | L2 MUS Threshold |\n")
            f.write("|------------|-------------|------------------|------------------|\n")
            
            for scenario_id, config in SCENARIOS.items():
                l1_threshold = config["env_vars"].get("MEMORY_PRUNING_L1_MUS_THRESHOLD", "N/A")
                l2_threshold = config["env_vars"].get("MEMORY_PRUNING_L2_MUS_THRESHOLD", "N/A")
                f.write(f"| {scenario_id} | {config['description']} | {l1_threshold} | {l2_threshold} |\n")
            
            f.write("\n## Quantitative Results\n\n")
            f.write("### Memory Counts\n\n")
            f.write("| Scenario ID | Total Memories | L1 Count | L2 Count | Pruned L1 | Pruned L2 | Avg L1 MUS | Avg L2 MUS |\n")
            f.write("|------------|----------------|----------|----------|-----------|-----------|------------|------------|\n")
            
            for scenario_id, scenario_data in comparative_data["scenarios"].items():
                metrics = scenario_data["memory_metrics"]
                f.write(f"| {scenario_id} | {metrics['total_memories']} | {metrics['l1_count']} | {metrics['l2_count']} | ")
                f.write(f"{metrics['pruned_l1']} | {metrics['pruned_l2']} | ")
                f.write(f"{metrics['avg_l1_mus']:.3f} | {metrics['avg_l2_mus']:.3f} |\n")
            
            f.write("\n### Memory Efficiency Scores\n\n")
            f.write("| Scenario ID | Memory Efficiency Score |\n")
            f.write("|------------|-------------------------|\n")
            
            for scenario_id, scenario_data in comparative_data["scenarios"].items():
                f.write(f"| {scenario_id} | {scenario_data.get('memory_efficiency_score', 0.0):.3f} |\n")
            
            f.write("\n### RAG Assessment\n\n")
            f.write("RAG assessment results will be added after human evaluation of query responses.\n\n")
            
            f.write("## Memory Count Visualization\n\n")
            f.write("![Memory Counts by Scenario](./tuning_results/memory_counts.png)\n\n")
            
            f.write("## Efficiency Scores Visualization\n\n")
            f.write("![Efficiency Scores by Scenario](./tuning_results/efficiency_scores.png)\n\n")
            
            f.write("## Recommendations\n\n")
            
            # Get the recommended configuration
            recommended_id = comparative_data["summary"]["recommended_configuration"]
            if recommended_id:
                recommended_config = SCENARIOS.get(recommended_id, {})
                f.write(f"Based on the current analysis, the recommended configuration is **{recommended_id}**: ")
                f.write(f"{recommended_config.get('description', '')}\n\n")
                
                f.write("### Recommended MUS Threshold Settings\n\n")
                f.write("| Parameter | Value |\n")
                f.write("|-----------|-------|\n")
                
                env_vars = recommended_config.get("env_vars", {})
                for key, value in env_vars.items():
                    if "THRESHOLD" in key or "ENABLED" in key:
                        f.write(f"| {key} | {value} |\n")
            else:
                f.write("No clear recommendation available yet. Further analysis required.\n\n")
            
            f.write("\n## Next Steps\n\n")
            f.write("1. Complete human evaluation of RAG query responses to assess information retrieval quality\n")
            f.write("2. Update the report with RAG performance metrics\n")
            f.write("3. Refine recommendations based on combined memory efficiency and RAG performance\n")
            
        logger.info(f"Markdown report generated successfully at {REPORT_PATH}")
    
    except Exception as e:
        logger.error(f"Error generating markdown report: {e}")

def main():
    """Main function to run all experiments and generate reports."""
    try:
        # Parse command-line arguments
        args = parse_args()
        
        # Update global variables based on command-line args
        global SIM_STEPS, NUM_AGENTS, RESULTS_DIR
        SIM_STEPS = args.steps
        NUM_AGENTS = args.num_agents
        
        if args.output_dir:
            RESULTS_DIR = Path(args.output_dir)
        
        # Determine which scenarios to run
        scenario_ids_to_run = args.scenarios if args.scenarios else list(SCENARIOS.keys())
        
        # Validate scenario IDs
        invalid_scenarios = [sid for sid in scenario_ids_to_run if sid not in SCENARIOS]
        if invalid_scenarios:
            logger.error(f"Invalid scenario IDs: {', '.join(invalid_scenarios)}")
            logger.info(f"Available scenarios: {', '.join(SCENARIOS.keys())}")
            return 1
        
        logger.info(f"Starting MUS Pruning Threshold Tuning Experiments")
        logger.info(f"Mode: {'DRY RUN' if args.dry_run else 'FULL EXECUTION'}")
        logger.info(f"Scenarios to run: {', '.join(scenario_ids_to_run)}")
        logger.info(f"Simulation steps: {SIM_STEPS}")
        logger.info(f"Number of agents: {NUM_AGENTS}")
        logger.info(f"Output directory: {RESULTS_DIR}")
        
        # Setup results directories
        setup_results_directories()
        
        # Store results for each scenario
        all_results = {}
        
        # Run each scenario
        for scenario_id in scenario_ids_to_run:
            config = SCENARIOS[scenario_id]
            logger.info(f"------ Starting scenario: {scenario_id} ------")
            
            if args.dry_run:
                logger.info(f"DRY RUN: Would run simulation for {scenario_id} with config:")
                for key, value in config["env_vars"].items():
                    logger.info(f"  {key}={value}")
                logger.info(f"------ Completed scenario (dry run): {scenario_id} ------")
                
                # Create dummy results for dry run
                all_results[scenario_id] = {
                    "scenario_id": scenario_id,
                    "description": config["description"],
                    "agents": {f"agent_{i}": {"l1_count": 10 * i, "l2_count": 5 * i} for i in range(1, NUM_AGENTS + 1)},
                    "total_l1_count": 100,
                    "total_l2_count": 50,
                    "total_memories": 150,
                    "avg_l1_mus": 0.3,
                    "avg_l2_mus": 0.4,
                    "pruning_stats": {
                        "total_l1_pruned": 30,
                        "total_l2_pruned": 15,
                        "pruning_events": 5
                    }
                }
                continue
            
            # Run the simulation
            success = run_simulation(scenario_id, config)
            
            if success:
                # Extract memory metrics
                metrics = extract_memory_metrics(scenario_id)
                
                # Perform RAG assessment (unless skipped)
                if not args.skip_rag_assessment:
                    rag_results = perform_rag_assessment(scenario_id)
                
                # Store results
                all_results[scenario_id] = metrics
                
                logger.info(f"------ Completed scenario: {scenario_id} ------")
            else:
                logger.error(f"------ Failed scenario: {scenario_id} ------")
        
        # Generate comparative report
        if all_results:
            generate_comparative_report(all_results)
            logger.info("Experiments completed successfully")
            return 0
        else:
            logger.error("No results were collected. Report generation skipped.")
            return 1
    
    except Exception as e:
        logger.error(f"Unhandled exception in main: {e}")
        return 1

if __name__ == "__main__":
    sys.exit(main()) 