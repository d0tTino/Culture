# Role Adherence Implementation Recommendations

## Overview

Based on our experiments with DSPy and direct prompt engineering approaches, we have developed specific recommendations for implementing improved role adherence in the Culture.ai agent system. The focus is on ensuring that agents generate thoughts that consistently reflect their assigned roles (Innovator, Analyzer, Facilitator), leading to more coherent and purposeful agent behaviors.

## Key Findings from Experiments

1. **Effective Prompt Structure**: A well-crafted prompt template that includes the role description and explicit instructions to begin with "As a [role]" produces consistently high role adherence.

2. **Role-Specific Evaluation**: Our simple role adherence metrics (keyword presence and role phrase inclusion) proved effective in quantifying adherence levels.

3. **Model Capability**: The mistral:latest model via Ollama demonstrated strong role adherence capabilities without requiring complex optimization frameworks.

4. **DSPy Integration**: While DSPy offers promising optimization capabilities, direct prompt engineering is immediately effective and can be implemented without complex infrastructure changes.

## Recommended Implementation

### 1. Integration into Agent Graph

Modify the `generate_thought_and_message_node` function in `src/agents/graphs/basic_agent_graph.py` to use our validated prompt template for role adherence:

```python
def generate_thought_and_message_node(state: AgentTurnState) -> Dict[str, Optional[AgentActionOutput]]:
    """
    Node that calls the LLM to generate structured output (thought, message_content, message_recipient_id, intent)
    based on context.
    """
    # ... existing code for extracting state information ...
    
    # Get the raw current role string
    raw_role_name = agent_state.role
    
    # Get role description and role-specific guidance
    role_description = ROLE_DESCRIPTIONS.get(raw_role_name, f"{raw_role_name}: Contribute effectively based on your role.")
    role_specific_guidance = ROLE_PROMPT_SNIPPETS.get(raw_role_name, "Consider how your role might influence your perspective and contributions.")
    
    # ... existing code for other state extraction ...
    
    # Build the prompt with enhanced role adherence instructions
    prompt_parts = []
    prompt_parts.append(f"You are Agent_{agent_id}, an AI agent in a simulation.")
    prompt_parts.append(f"Current simulation step: {sim_step}.")
    
    # Add clear role instructions (NEW)
    prompt_parts.append(f"\nYou are acting as an agent with the specific role of {raw_role_name}.")
    prompt_parts.append(f"ROLE: {raw_role_name}")
    prompt_parts.append(f"ROLE DESCRIPTION: {role_description}")
    prompt_parts.append(f"ROLE GUIDANCE: {role_specific_guidance}")
    
    # ... other existing prompt sections ...
    
    # Add specific instruction for thought generation (NEW)
    prompt_parts.append(f"\nIMPORTANT INSTRUCTION FOR THOUGHT GENERATION:")
    prompt_parts.append(f"Your internal thought must strongly reflect your role as a {raw_role_name}.")
    prompt_parts.append(f"Begin your thought with 'As a {raw_role_name},' and ensure your entire thought process clearly demonstrates thinking consistent with your role description.")
    
    # ... rest of existing function ...
```

### 2. Verification Mechanism

Implement a simple verification function to check if the generated thought adheres to the agent's role:

```python
def verify_role_adherence(thought: str, role: str) -> Dict[str, Any]:
    """
    Verify if a generated thought adheres to the specified role.
    Returns metrics about role adherence.
    """
    thought_lower = thought.lower()
    role_lower = role.lower()
    
    # Define role-specific keywords
    role_keywords = {
        "innovator": ["new", "novel", "creative", "idea", "innovative", "unconventional"],
        "analyzer": ["evaluate", "analysis", "risk", "consider", "examine", "critical", "flaw"],
        "facilitator": ["summarize", "consensus", "collaboration", "discussion", "synthesis", "clarify"]
    }
    
    # Count keyword matches
    keywords = role_keywords.get(role_lower, [])
    matches = sum(1 for keyword in keywords if keyword in thought_lower)
    
    # Check for role phrase
    role_phrase = f"as a {role_lower}"
    alt_role_phrase = f"as an {role_lower}"
    has_role_phrase = role_phrase in thought_lower or alt_role_phrase in thought_lower
    
    # Calculate score
    score = min(1.0, matches / 4)  # Normalize to 0-1 range
    if has_role_phrase:
        score = min(1.0, score + 0.3)  # Boost score if explicit role mention exists
    
    return {
        "role": role,
        "score": score,
        "passes_threshold": score >= 0.5,
        "keyword_matches": matches,
        "has_role_phrase": has_role_phrase
    }
```

### 3. Integration with Memory

Record the role adherence metrics in the agent's memory to track consistency over time:

```python
def update_state_node(state: AgentTurnState) -> Dict[str, Any]:
    """Update the agent state based on the turn's outcome."""
    # ... existing code ...
    
    # Add role adherence verification (NEW)
    if "structured_output" in state and state["structured_output"] is not None:
        thought = state["structured_output"].thought
        role = state["current_role"]
        
        # Verify role adherence
        adherence_metrics = verify_role_adherence(thought, role)
        
        # Add to agent memory if role adherence is poor
        if not adherence_metrics["passes_threshold"]:
            state["state"].add_memory(
                state["simulation_step"],
                "role_adherence",
                f"Generated thought showed weak adherence to {role} role (score: {adherence_metrics['score']:.2f})"
            )
        
        # Update state with metrics
        state["role_adherence_score"] = adherence_metrics["score"]
    
    # ... rest of existing function ...
```

### 4. Logging for Analysis

Add logging of role adherence metrics for analysis and tuning:

```python
# Add to the appropriate logging section
logger.debug(f"  Role adherence score: {state.get('role_adherence_score', 'N/A')}")
```

## Fallback Mechanism (Optional)

For critical cases where role adherence is essential, consider implementing a fallback mechanism that regenerates thoughts with poor role adherence:

```python
def ensure_role_adherent_thought(state: AgentTurnState) -> Dict[str, Any]:
    """Ensure the generated thought adheres to the agent's role, regenerating if necessary."""
    # Generate initial thought
    result = generate_thought_and_message_node(state)
    
    # Check role adherence
    if "structured_output" in result and result["structured_output"] is not None:
        thought = result["structured_output"].thought
        role = state["current_role"]
        adherence_metrics = verify_role_adherence(thought, role)
        
        # If adherence is poor, try once more with stronger instructions
        if not adherence_metrics["passes_threshold"] and adherence_metrics["score"] < 0.4:
            logger.info(f"Low role adherence detected (score: {adherence_metrics['score']:.2f}). Regenerating thought with stronger role emphasis.")
            
            # Modify state to emphasize role more strongly
            state["emphasize_role"] = True
            
            # Regenerate thought
            result = generate_thought_and_message_node(state)
    
    return result
```

## Testing and Validation

Before full implementation, we recommend:

1. **A/B Testing**: Run a small simulation with both the current and new thought generation approaches to compare role adherence.

2. **Role-Specific Analysis**: Analyze the performance separately for each role to identify if certain roles need additional tuning.

3. **Performance Impact**: Measure any impact on LLM call latency from the enhanced prompts and verification.

## Long-Term Improvements

For future development:

1. **DSPy Integration**: Once the technical challenges are resolved, explore DSPy for more sophisticated prompt optimization.

2. **Expanded Role Definitions**: Consider expanding the role definitions and evaluation metrics to capture more nuanced aspects of each role.

3. **Dynamic Role Adaptation**: Explore mechanisms for agents to adapt their role-based behavior based on the success of past interactions.

## Conclusion

Implementing these recommendations will significantly improve role adherence in agent thought generation, leading to more coherent and purposeful agent behaviors in the Culture.ai simulation. The direct prompt engineering approach provides immediate benefits while setting the foundation for more sophisticated optimizations in the future. 