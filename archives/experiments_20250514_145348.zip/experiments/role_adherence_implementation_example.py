"""
Role Adherence Implementation Example for Culture.ai

This file shows a concrete example of how to implement the role adherence approach
in the existing agent graph code (src/agents/graphs/basic_agent_graph.py).
"""

# The verification function for measuring role adherence
def verify_role_adherence(thought: str, role: str) -> dict:
    """
    Verify if a generated thought adheres to the specified role.
    Returns metrics about role adherence.
    
    Args:
        thought: The agent's generated thought to verify
        role: The agent's assigned role (Innovator, Analyzer, Facilitator)
        
    Returns:
        Dictionary with metrics including score, passes_threshold, etc.
    """
    thought_lower = thought.lower()
    role_lower = role.lower()
    
    # Define role-specific keywords
    role_keywords = {
        "innovator": ["new", "novel", "creative", "idea", "innovative", "unconventional", "possibility"],
        "analyzer": ["evaluate", "analysis", "risk", "consider", "examine", "critical", "flaw", "practical"],
        "facilitator": ["summarize", "consensus", "collaboration", "discussion", "synthesis", "clarify", "communication"]
    }
    
    # Count keyword matches
    keywords = role_keywords.get(role_lower, [])
    matches = sum(1 for keyword in keywords if keyword in thought_lower)
    
    # Check for role phrase
    role_phrase = f"as a {role_lower}"
    alt_role_phrase = f"as an {role_lower}"
    has_role_phrase = role_phrase in thought_lower or alt_role_phrase in thought_lower
    
    # Calculate score
    score = min(1.0, matches / 4)  # Normalize to 0-1 range
    if has_role_phrase:
        score = min(1.0, score + 0.3)  # Boost score if explicit role mention exists
    
    return {
        "role": role,
        "score": score,
        "passes_threshold": score >= 0.5,
        "keyword_matches": matches,
        "has_role_phrase": has_role_phrase
    }

# Example of how to modify the generate_thought_and_message_node function
def generate_thought_and_message_node_enhanced(state: dict) -> dict:
    """
    Enhanced node that generates thought and message with improved role adherence.
    This shows how to modify the existing function in basic_agent_graph.py.
    
    Only the relevant parts are shown - the rest would remain unchanged.
    """
    # Existing code to extract agent information
    agent_id = state["agent_id"]
    agent_state = state["state"]
    sim_step = state["simulation_step"]
    
    # Get role information
    raw_role_name = agent_state.role
    
    # Get role description - this would come from your role definitions
    # In your case, you'd use ROLE_DESCRIPTIONS.get(raw_role_name, ...)
    role_description = f"{raw_role_name}: A member of the simulation with specific strengths."
    role_specific_guidance = f"As a {raw_role_name}, consider how your unique perspective contributes to the discussion."
    
    # Building the prompt with enhanced role adherence elements
    prompt_parts = []
    
    # Standard agent identification (existing code)
    prompt_parts.append(f"You are Agent_{agent_id}, an AI agent in a simulation.")
    prompt_parts.append(f"Current simulation step: {sim_step}.")
    
    # Add clear role instructions (NEW)
    prompt_parts.append(f"\nYou are acting as an agent with the specific role of {raw_role_name}.")
    prompt_parts.append(f"ROLE: {raw_role_name}")
    prompt_parts.append(f"ROLE DESCRIPTION: {role_description}")
    prompt_parts.append(f"ROLE GUIDANCE: {role_specific_guidance}")
    
    # Other existing prompt parts would go here
    # prompt_parts.append(...)
    
    # Add specific instruction for thought generation (NEW)
    prompt_parts.append(f"\nIMPORTANT INSTRUCTION FOR THOUGHT GENERATION:")
    prompt_parts.append(f"Your internal thought must strongly reflect your role as a {raw_role_name}.")
    prompt_parts.append(f"Begin your thought with 'As a {raw_role_name},' and ensure your entire thought process clearly demonstrates thinking consistent with your role description.")
    
    # Combine all prompt parts into a single prompt
    prompt = "\n".join(prompt_parts)
    
    # Call the LLM with the enhanced prompt (existing code)
    response = generate_structured_output(prompt, model="mistral:latest")
    
    # NEW: Verify role adherence of the generated thought
    if response is not None and hasattr(response, "thought"):
        adherence_metrics = verify_role_adherence(response.thought, raw_role_name)
        
        # Log adherence metrics
        logger.debug(f"Role adherence for Agent {agent_id}: score={adherence_metrics['score']:.2f}, passes={adherence_metrics['passes_threshold']}")
        
        # Optionally store metrics in state for later analysis
        state["role_adherence_metrics"] = adherence_metrics
        
        # OPTIONAL: Regenerate thought if adherence is poor
        # This is an advanced feature that can be implemented later
        if not adherence_metrics["passes_threshold"] and adherence_metrics["score"] < 0.3:
            logger.info(f"Low role adherence detected ({adherence_metrics['score']:.2f}). Regenerating thought with stronger emphasis.")
            
            # Add stronger emphasis to the prompt
            prompt_parts.append(f"\nIMPORTANT: Your previous response did not sufficiently reflect your role as a {raw_role_name}.")
            prompt_parts.append(f"Please ensure your thought process CLEARLY demonstrates the {raw_role_name} perspective.")
            enhanced_prompt = "\n".join(prompt_parts)
            
            # Regenerate with enhanced prompt
            response = generate_structured_output(enhanced_prompt, model="mistral:latest")
    
    # Return the result (existing code)
    return {"structured_output": response}

# Example of how to add role adherence monitoring to the update_state_node
def update_state_node_enhanced(state: dict) -> dict:
    """
    Enhanced update_state node that records role adherence metrics.
    This shows how to modify the existing function in basic_agent_graph.py.
    
    Only the relevant parts are shown - the rest would remain unchanged.
    """
    # Existing state update code would go here
    # ...
    
    # NEW: Record role adherence metrics if available
    if "role_adherence_metrics" in state:
        metrics = state["role_adherence_metrics"]
        
        # Add to agent memory if adherence was poor
        if not metrics["passes_threshold"]:
            state["state"].add_memory(
                state["simulation_step"],
                "role_adherence",
                f"Generated thought showed weak adherence to {metrics['role']} role (score: {metrics['score']:.2f})"
            )
        
        # Add metrics to agent state for long-term analysis
        if not hasattr(state["state"], "role_adherence_history"):
            state["state"].role_adherence_history = []
            
        state["state"].role_adherence_history.append({
            "step": state["simulation_step"],
            "score": metrics["score"],
            "passes_threshold": metrics["passes_threshold"]
        })
    
    # Return updated state (existing code)
    return {"updated_state": state["state"]}

# This is just an example - in practice, you would modify the existing functions
# in src/agents/graphs/basic_agent_graph.py rather than creating new ones 