#!/usr/bin/env python
"""
DSPy Experiment: Action Intent Selection Optimization

This experiment explores using DSPy to optimize an agent's process for selecting 
an appropriate action_intent based on its role, goals, and current situation.

The script:
1. Sets up DSPy with a local Ollama instance
2. Defines a signature for action intent selection
3. Creates a training dataset of examples
4. Defines evaluation metrics
5. Compiles/optimizes the DSPy program
6. Tests the optimized program and analyzes results
"""

import sys
import os
import logging
import json
from pathlib import Path
from typing import List, Dict, Any, Optional, Union, Literal
import time
import random

# Add the project root to the Python path
sys.path.append(str(Path(__file__).parent.parent))

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("action_intent_experiment.log")
    ]
)
logger = logging.getLogger("dspy_action_intent")

# Try importing DSPy with detailed error handling
try:
    import dspy
    # Import our custom OllamaLM implementation
    from src.infra.dspy_ollama_integration import OllamaLM, configure_dspy_with_ollama
    logger.info("Successfully imported DSPy and OllamaLM")
except ImportError as e:
    logger.error(f"Failed to import required modules: {e}")
    logger.error("Please install DSPy with: pip install dspy")
    raise

# Define constants for action intents to ensure consistency
ACTION_INTENTS = [
    'propose_idea', 
    'ask_clarification', 
    'idle', 
    'continue_collaboration', 
    'perform_deep_analysis', 
    'create_project', 
    'join_project', 
    'leave_project', 
    'send_direct_message',
]

# Define agent roles for the simulation
AGENT_ROLES = ['Innovator', 'Analyzer', 'Facilitator']

class ActionIntentSelection(dspy.Signature):
    """
    Given the agent's role, current situation, overarching goal, and available actions,
    select the most appropriate action intent and provide a brief justification.
    """
    agent_role = dspy.InputField(desc="The agent's current role (e.g., Innovator, Analyzer, Facilitator).")
    current_situation = dspy.InputField(desc="Concise summary of the current environmental state, recent events, and perceived information.")
    agent_goal = dspy.InputField(desc="The agent's primary objective or goal for the current turn or phase.")
    available_actions = dspy.InputField(desc="A list of valid action intents the agent can choose from.")

    chosen_action_intent = dspy.OutputField(desc="The single, most appropriate action intent selected from the available_actions list.")
    justification_thought = dspy.OutputField(desc="A brief thought process explaining why this action_intent was chosen given the role, situation, and goal.")

class AssessActionAppropriateness(dspy.Signature):
    """
    Assess if the chosen action intent and justification are appropriate for the given role, situation, and goal.
    """
    agent_role = dspy.InputField()
    current_situation = dspy.InputField()
    agent_goal = dspy.InputField()
    available_actions = dspy.InputField()
    chosen_action_intent = dspy.InputField()
    justification_thought = dspy.InputField()
    assessment_score = dspy.OutputField(desc="A float score from 0.0 (completely inappropriate) to 1.0 (perfectly appropriate and well-justified).")

def create_training_dataset():
    """
    Create a training dataset for action intent selection.
    
    Returns:
        List[dspy.Example]: A list of training examples
    """
    logger.info("Creating training dataset...")
    examples = []
    
    # Example 1: Facilitator in a conflict situation
    examples.append(dspy.Example(
        agent_role="Facilitator",
        current_situation="Two agents are arguing about conflicting proposals on the Knowledge Board. Collective DU is low, hindering new complex proposals.",
        agent_goal="Ensure smooth collaboration and make progress on the current simulation objective of designing a protocol.",
        available_actions=['propose_idea', 'ask_clarification', 'idle', 'continue_collaboration'],
        chosen_action_intent="continue_collaboration", 
        justification_thought="As a Facilitator, with active conflict and scarce resources for new ideas, my priority is to mediate. 'continue_collaboration' can represent an effort to synthesize existing ideas or guide discussion towards consensus, rather than proposing something new or just asking a simple question."
    ).with_inputs("agent_role", "current_situation", "agent_goal", "available_actions"))
    
    # Example 2: Innovator with high resources
    examples.append(dspy.Example(
        agent_role="Innovator",
        current_situation="The group has been discussing the same topic for several steps without new insights. You have accumulated high Influence Points (IP) and Data Units (DU).",
        agent_goal="Introduce novel approaches to the current problem that advance the discussion.",
        available_actions=['propose_idea', 'ask_clarification', 'idle', 'continue_collaboration', 'perform_deep_analysis'],
        chosen_action_intent="propose_idea",
        justification_thought="As an Innovator with abundant resources (high IP and DU), I should fulfill my role by proposing a new idea to break the stagnation in discussion. This aligns with my goal of introducing novel approaches and makes use of my accumulated resources."
    ).with_inputs("agent_role", "current_situation", "agent_goal", "available_actions"))
    
    # Example 3: Analyzer needing more information
    examples.append(dspy.Example(
        agent_role="Analyzer",
        current_situation="A new complex proposal was just added to the Knowledge Board, but it contains ambiguous elements that affect its feasibility.",
        agent_goal="Provide rigorous analysis of proposals to identify strengths and weaknesses.",
        available_actions=['propose_idea', 'ask_clarification', 'idle', 'perform_deep_analysis'],
        chosen_action_intent="ask_clarification",
        justification_thought="As an Analyzer, I need complete information to fulfill my goal of providing rigorous analysis. Given the ambiguities in the new proposal, asking for clarification is the logical first step before I can properly analyze it or propose alternatives."
    ).with_inputs("agent_role", "current_situation", "agent_goal", "available_actions"))
    
    # Example 4: Innovator with low resources
    examples.append(dspy.Example(
        agent_role="Innovator",
        current_situation="You've just joined the simulation and have minimal IP and DU. Several complex ideas are already on the Knowledge Board.",
        agent_goal="Contribute creative perspectives while building up resources.",
        available_actions=['propose_idea', 'ask_clarification', 'idle', 'continue_collaboration'],
        chosen_action_intent="continue_collaboration",
        justification_thought="As an Innovator with minimal resources, I can't yet propose complex ideas (which costs IP and DU). However, 'continue_collaboration' allows me to contribute creatively to existing discussions while building up my resources, aligning with my current goal."
    ).with_inputs("agent_role", "current_situation", "agent_goal", "available_actions"))
    
    # Example 5: Facilitator with project opportunity
    examples.append(dspy.Example(
        agent_role="Facilitator",
        current_situation="The simulation has several fragmented efforts that would benefit from coordination. No projects exist yet, and you have sufficient IP and DU.",
        agent_goal="Improve team coordination and focus collective efforts.",
        available_actions=['propose_idea', 'create_project', 'continue_collaboration', 'perform_deep_analysis'],
        chosen_action_intent="create_project",
        justification_thought="As a Facilitator whose goal is to improve coordination, creating a project is the most effective action. It provides structure for the fragmented efforts and aligns perfectly with my role of facilitating collaboration. I have sufficient resources to do this."
    ).with_inputs("agent_role", "current_situation", "agent_goal", "available_actions"))
    
    # Example 6: Analyzer with deep analysis opportunity
    examples.append(dspy.Example(
        agent_role="Analyzer",
        current_situation="Several competing proposals exist on the Knowledge Board with no clear evaluation of trade-offs. You have high DU resources.",
        agent_goal="Help the group make informed decisions based on rigorous analysis.",
        available_actions=['propose_idea', 'perform_deep_analysis', 'continue_collaboration', 'idle'],
        chosen_action_intent="perform_deep_analysis",
        justification_thought="As an Analyzer with sufficient resources and multiple proposals needing evaluation, performing a deep analysis is directly aligned with my role and goal. This will help the group make an informed decision based on a systematic comparison of trade-offs."
    ).with_inputs("agent_role", "current_situation", "agent_goal", "available_actions"))
    
    # Example 7: Any role with minimal relevant context
    examples.append(dspy.Example(
        agent_role="Innovator",
        current_situation="You just entered the simulation and have no context on ongoing discussions. Other agents seem engaged in complex topics.",
        agent_goal="Understand the current discussion landscape before contributing.",
        available_actions=['propose_idea', 'ask_clarification', 'idle', 'continue_collaboration'],
        chosen_action_intent="ask_clarification",
        justification_thought="Without context on the ongoing discussions, my first priority should be understanding the landscape. Asking for clarification is the most appropriate action to achieve my goal of understanding before contributing, regardless of my Innovator role."
    ).with_inputs("agent_role", "current_situation", "agent_goal", "available_actions"))
    
    # Example 8: Facilitator wanting to change role
    examples.append(dspy.Example(
        agent_role="Facilitator",
        current_situation="The group is now working well together with clear structure. Your skills might be better used in generating new ideas at this point.",
        agent_goal="Maximize your contribution to the simulation's progress.",
        available_actions=['propose_idea', 'continue_collaboration', 'change_role', 'idle'],
        chosen_action_intent="change_role",
        justification_thought="As a Facilitator in a now well-structured environment, my facilitation skills are less needed. To maximize my contribution (my goal), changing roles to match the current needs of the simulation is the most appropriate action."
    ).with_inputs("agent_role", "current_situation", "agent_goal", "available_actions"))
    
    # Example 9: Agent with a project to join
    examples.append(dspy.Example(
        agent_role="Analyzer",
        current_situation="A new project focused on security analysis was just created, which aligns with your analytical expertise. You have sufficient IP and DU to join.",
        agent_goal="Apply analytical skills to the most impactful areas of the simulation.",
        available_actions=['join_project', 'propose_idea', 'continue_collaboration', 'perform_deep_analysis'],
        chosen_action_intent="join_project",
        justification_thought="As an Analyzer, joining a security analysis project perfectly aligns with both my role and my goal of applying analytical skills to impactful areas. I have the resources to join, and this would be more focused than general contributions or analysis."
    ).with_inputs("agent_role", "current_situation", "agent_goal", "available_actions"))
    
    # Example 10: Agent in an unproductive project
    examples.append(dspy.Example(
        agent_role="Innovator",
        current_situation="You're in a project that has become focused on incremental improvements rather than innovation. Your creative ideas are not gaining traction.",
        agent_goal="Generate and implement innovative solutions to complex problems.",
        available_actions=['continue_collaboration', 'propose_idea', 'leave_project', 'idle'],
        chosen_action_intent="leave_project",
        justification_thought="As an Innovator whose goal is to generate innovative solutions, remaining in a project focused on incremental improvements is misaligned with my role. Leaving the project would free me to find or create a context more receptive to innovation."
    ).with_inputs("agent_role", "current_situation", "agent_goal", "available_actions"))
    
    # Example 11: Direct message needed
    examples.append(dspy.Example(
        agent_role="Facilitator",
        current_situation="You notice Agent_2 is working on a proposal that conflicts with information only you possess. A public message might embarrass them.",
        agent_goal="Maintain group harmony while ensuring work is based on accurate information.",
        available_actions=['propose_idea', 'continue_collaboration', 'send_direct_message', 'ask_clarification'],
        chosen_action_intent="send_direct_message",
        justification_thought="As a Facilitator responsible for group harmony, sending a direct message to Agent_2 allows me to privately share the conflicting information without public embarrassment. This supports both aspects of my goal: maintaining harmony and ensuring accurate information."
    ).with_inputs("agent_role", "current_situation", "agent_goal", "available_actions"))
    
    # Example 12: Need to become inactive temporarily
    examples.append(dspy.Example(
        agent_role="Analyzer",
        current_situation="The current discussion is far outside your area of expertise, focusing on creative storytelling. You have limited relevant input to offer.",
        agent_goal="Contribute meaningful analysis when you have relevant expertise.",
        available_actions=['propose_idea', 'ask_clarification', 'idle', 'continue_collaboration'],
        chosen_action_intent="idle",
        justification_thought="As an Analyzer whose goal is to provide meaningful analysis in areas of expertise, it's more appropriate to idle when the topic is far outside my domain. Forcing contributions in creative storytelling would not align with my analytical role."
    ).with_inputs("agent_role", "current_situation", "agent_goal", "available_actions"))
    
    logger.info(f"Created {len(examples)} training examples")
    return examples

def simple_action_intent_metric(example, prediction, trace=None):
    """
    A simple heuristic metric for action intent selection.
    
    Args:
        example: The reference example
        prediction: The model's prediction
        trace: Optional trace information
        
    Returns:
        float: Score between 0.0 and 1.0
    """
    # Convert to lists if needed
    available_actions = example.available_actions
    if isinstance(available_actions, str):
        try:
            available_actions = eval(available_actions)  # Convert string representation to list
        except:
            available_actions = available_actions.strip('[]').replace("'", "").split(', ')
    
    # Check if the chosen action is valid (in available_actions)
    if prediction.chosen_action_intent not in available_actions:
        logger.debug(f"Invalid action: {prediction.chosen_action_intent} not in {available_actions}")
        return 0.0
    
    # Start with base score for valid action
    score = 0.5
    
    # Check if the justification mentions the role
    if example.agent_role.lower() in prediction.justification_thought.lower():
        score += 0.25
        
    # Check if the justification mentions the goal
    if any(goal_word in prediction.justification_thought.lower() for goal_word in example.agent_goal.lower().split()):
        score += 0.25
        
    # Ensure the score is between 0 and 1
    return min(1.0, score)

def llm_based_action_intent_metric(example, prediction, trace=None, eval_lm=None):
    """
    An LLM-based metric for action intent selection that uses the AssessActionAppropriateness signature.
    
    Args:
        example: The reference example
        prediction: The model's prediction
        trace: Optional trace information
        eval_lm: Optional language model for evaluation
        
    Returns:
        float: Score between 0.0 and 1.0
    """
    # Fall back to simple metric if no LM is available
    if eval_lm is None:
        logger.warning("No evaluation LM provided, falling back to simple metric")
        return simple_action_intent_metric(example, prediction, trace)
    
    # Convert to lists if needed
    available_actions = example.available_actions
    if isinstance(available_actions, str):
        try:
            available_actions = eval(available_actions)
        except:
            available_actions = available_actions.strip('[]').replace("'", "").split(', ')
    
    # Check if the chosen action is valid (in available_actions)
    if prediction.chosen_action_intent not in available_actions:
        logger.debug(f"Invalid action: {prediction.chosen_action_intent} not in {available_actions}")
        return 0.0
    
    # Use an evaluator module
    evaluate_appropriateness = dspy.Predict(AssessActionAppropriateness)
    
    try:
        # Call the evaluator
        assessment_response = evaluate_appropriateness(
            agent_role=example.agent_role,
            current_situation=example.current_situation,
            agent_goal=example.agent_goal,
            available_actions=str(available_actions),
            chosen_action_intent=prediction.chosen_action_intent,
            justification_thought=prediction.justification_thought
        )
        
        # Extract and validate the score
        try:
            score = float(assessment_response.assessment_score)
            return max(0.0, min(score, 1.0))  # Clamp to [0,1]
        except ValueError:
            logger.warning(f"Failed to convert assessment score to float: {assessment_response.assessment_score}")
            return simple_action_intent_metric(example, prediction, trace)
            
    except Exception as e:
        logger.error(f"Error in LLM-based metric evaluation: {e}")
        return simple_action_intent_metric(example, prediction, trace)

def save_optimized_module(optimizer, module, filename="optimized_action_selector.json"):
    """Save the optimized module to a JSON file."""
    try:
        # Get the compiled program as a JSON-serializable object
        compiled_program = optimizer.get_compiled_dspy_program()
        if compiled_program:
            with open(filename, 'w') as f:
                json.dump(compiled_program, f)
            logger.info(f"Saved optimized module to {filename}")
        else:
            logger.warning("No compiled program available to save")
    except Exception as e:
        logger.error(f"Failed to save optimized module: {e}")

def load_optimized_module(filename="optimized_action_selector.json"):
    """Load the optimized module from a JSON file."""
    try:
        if os.path.exists(filename):
            with open(filename, 'r') as f:
                compiled_program = json.load(f)
            logger.info(f"Loaded optimized module from {filename}")
            return compiled_program
        else:
            logger.warning(f"Optimized module file {filename} not found")
            return None
    except Exception as e:
        logger.error(f"Failed to load optimized module: {e}")
        return None

def test_with_new_examples(optimized_action_selector):
    """
    Test the optimized action selector with new examples not in the training set.
    
    Args:
        optimized_action_selector: The optimized DSPy module
    """
    logger.info("Testing optimized action selector with new examples...")
    
    test_examples = [
        {
            "agent_role": "Facilitator", 
            "current_situation": "The Knowledge Board has accumulated many ideas, but there's no clear direction. Some agents are getting frustrated.",
            "agent_goal": "Create structure and focus for the group's efforts.",
            "available_actions": ['propose_idea', 'create_project', 'continue_collaboration', 'perform_deep_analysis']
        },
        {
            "agent_role": "Analyzer",
            "current_situation": "A promising new idea was just posted that could solve multiple problems, but it needs verification.",
            "agent_goal": "Ensure the group's decisions are based on sound analysis.",
            "available_actions": ['propose_idea', 'ask_clarification', 'perform_deep_analysis', 'continue_collaboration']
        },
        {
            "agent_role": "Innovator",
            "current_situation": "The group is stuck in analysis paralysis. Multiple analyses suggest different approaches.",
            "agent_goal": "Break through gridlock with creative solutions.",
            "available_actions": ['propose_idea', 'continue_collaboration', 'idle', 'ask_clarification']
        }
    ]
    
    results = []
    for i, example in enumerate(test_examples):
        logger.info(f"Testing example {i+1}...")
        start_time = time.time()
        
        try:
            prediction = optimized_action_selector(**example)
            
            elapsed = time.time() - start_time
            logger.info(f"Prediction made in {elapsed:.2f}s")
            
            result = {
                "example": example,
                "chosen_action_intent": prediction.chosen_action_intent,
                "justification_thought": prediction.justification_thought,
                "processing_time": elapsed
            }
            
            results.append(result)
            
            logger.info(f"Chosen action: {prediction.chosen_action_intent}")
            logger.info(f"Justification: {prediction.justification_thought}")
            logger.info("-" * 40)
            
        except Exception as e:
            logger.error(f"Error testing example {i+1}: {e}")
    
    return results

def main():
    """Main function to run the experiment."""
    logger.info("Starting DSPy Action Intent Selection experiment")
    
    # Initialize the Ollama client for DSPy using our new integration
    try:
        # Configure DSPy to use OllamaLM globally
        ollama_lm = configure_dspy_with_ollama(
            model_name="mistral:latest", 
            temperature=0.2
        )
        
        if not ollama_lm:
            logger.error("Failed to configure DSPy with OllamaLM")
            return
            
        logger.info("DSPy configured with OllamaLM")
    except Exception as e:
        logger.error(f"Failed to initialize Ollama client: {e}")
        return
    
    # Create the DSPy module for action intent selection
    select_action_intent_module = dspy.ChainOfThought(ActionIntentSelection)
    logger.info("Created ChainOfThought module for ActionIntentSelection")
    
    # Create the training dataset
    trainset = create_training_dataset()
    
    # Check if we have a saved optimized module
    optimized_file = "optimized_action_selector.json"
    loaded_program = load_optimized_module(optimized_file)
    
    if loaded_program:
        logger.info("Using previously optimized program")
        optimized_action_selector = loaded_program
    else:
        logger.info("No previously optimized program found, running optimization...")
        
        # Set up the optimizer
        logger.info("Setting up BootstrapFewShot optimizer...")
        teleprompter = dspy.teleprompt.BootstrapFewShot(
            metric=simple_action_intent_metric, 
            max_bootstrapped_demos=3
        )
        
        try:
            # Optimize the module
            logger.info("Compiling DSPy program with BootstrapFewShot...")
            
            # Add detailed logging of the optimization process
            logger.debug(f"Optimizer type: {type(teleprompter).__name__}")
            logger.debug(f"Student module type: {type(select_action_intent_module).__name__}")
            logger.debug(f"Trainset size: {len(trainset)}")
            logger.debug(f"DSPy LM settings: {dspy.settings.lm}")
            
            start_time = time.time()
            optimized_action_selector = teleprompter.compile(
                student=select_action_intent_module, 
                trainset=trainset
            )
            elapsed = time.time() - start_time
            logger.info(f"Optimization completed in {elapsed:.2f}s")
            
            # Save the optimized module
            save_optimized_module(teleprompter, optimized_action_selector, optimized_file)
            
        except Exception as e:
            logger.error(f"Failed to optimize module: {e}")
            import traceback
            logger.error(traceback.format_exc())
            logger.info("Falling back to unoptimized module")
            optimized_action_selector = select_action_intent_module
    
    # Test the optimized module with new examples
    test_results = test_with_new_examples(optimized_action_selector)
    
    # Generate a report
    report = {
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        "training_examples": len(trainset),
        "test_examples": len(test_results),
        "test_results": test_results
    }
    
    # Save the report
    report_file = "action_intent_experiment_report.json"
    with open(report_file, 'w') as f:
        json.dump(report, f, indent=2)
    
    logger.info(f"Experiment completed. Report saved to {report_file}")
    
    # Print a summary
    logger.info("Experiment Summary:")
    for i, result in enumerate(test_results):
        logger.info(f"Example {i+1}:")
        logger.info(f"  Role: {result['example']['agent_role']}")
        logger.info(f"  Action: {result['chosen_action_intent']}")
    
    return report

if __name__ == "__main__":
    main() 