# DSPy Summarizer Optimization

This directory contains scripts for optimizing the L1 and L2 summary generators using DSPy's BootstrapFewShot teleprompter. These optimizations are part of Task 76, which builds upon the DSPy summarization components created in Task 74.

## Overview

The optimization process uses DSPy's BootstrapFewShot to find the most effective few-shot examples and prompting strategies for generating high-quality summaries. The process:

1. Evaluates the base (unoptimized) models using an LLM-as-judge approach
2. Uses BootstrapFewShot to compile optimized models
3. Evaluates the optimized models using the same metrics
4. Saves the optimized models if they show improvement

## Scripts

### Individual Scripts

- `optimize_l1_summarizer.py`: Optimizes the L1 (session-level) summary generator
- `optimize_l2_summarizer.py`: Optimizes the L2 (chapter-level) summary generator

### Combined Script

- `optimize_summarizers.py`: Runs both optimization scripts and generates a combined report

## Requirements

- Ollama must be installed and running locally with at least the `mistral:latest` model available
- The DSPy library must be installed (`pip install dspy-ai`)
- The project's directory structure must be set up with the existing L1 and L2 summary generators

## How to Run

Run the combined optimization script:

```bash
python experiments/optimize_summarizers.py
```

Or run the individual optimization scripts separately:

```bash
python experiments/optimize_l1_summarizer.py
python experiments/optimize_l2_summarizer.py
```

## Output Files

The optimization process generates several output files:

- Log files:
  - `experiments/l1_summary_optimization.log`: Log output from L1 optimization
  - `experiments/l2_summary_optimization.log`: Log output from L2 optimization
  - `experiments/summarizer_optimization.log`: Log output from combined script

- Compiled models:
  - `src/agents/dspy_programs/compiled/optimized_l1_summarizer.json`: Optimized L1 summarizer 
  - `src/agents/dspy_programs/compiled/optimized_l2_summarizer.json`: Optimized L2 summarizer
  - `experiments/compiled_models/optimized_l1_summarizer.json`: Backup copy of optimized L1 summarizer
  - `experiments/compiled_models/optimized_l2_summarizer.json`: Backup copy of optimized L2 summarizer

- Reports:
  - `experiments/l1_summarizer_optimization_report.json`: L1 optimization results
  - `experiments/l2_summarizer_optimization_report.json`: L2 optimization results
  - `experiments/dspy_summarizers_optimization_report.json`: Combined optimization results
  - `experiments/dspy_summarizers_optimization_report.md`: Combined report in Markdown format

## Integration

The L1 and L2 summary generator classes have been updated to automatically load these optimized models if they exist. No additional changes are required to use the optimized models in the agent's memory system.

## Evaluation Metrics

The optimization uses an LLM-as-judge approach to evaluate summary quality. The evaluation considers:

### L1 Summary Quality
- Faithfulness/Accuracy: Does it accurately reflect the original context?
- Relevance: Does it capture the most important information?
- Conciseness: Is it brief and to the point?
- Coherence: Is it well-written and easy to understand?

### L2 Summary Quality
- Comprehensiveness: Does it synthesize insights from multiple L1 summaries?
- Relevance to Goals: Is it aligned with the agent's current goals and role?
- Higher-level Insights: Does it provide deeper patterns beyond what's in individual L1 summaries?
- Coherence and Structure: Is it organized in a logical, readable way?

## Example Usage

The optimized summarizers are used automatically by the agent's memory system when generating L1 and L2 summaries. The `basic_agent_graph.py` file calls these summarizers during memory consolidation operations. 