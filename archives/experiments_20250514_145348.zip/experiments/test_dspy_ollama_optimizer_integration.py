#!/usr/bin/env python
"""
Test script for verifying the DSPy-Ollama integration with optimizers.

This script creates a minimal DSPy setup with a simple Signature, a training set,
and attempts to use a BootstrapFewShot optimizer to confirm the integration works.
"""

import sys
import os
import logging
import time
from pathlib import Path
from typing import Dict

# Add project root to path
project_root = Path(__file__).parent.parent
sys.path.append(str(project_root))

# Configure logging to see all debugging information
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("dspy_ollama_integration_test.log")
    ]
)
logger = logging.getLogger("dspy_ollama_test")

# Import DSPy and our OllamaLM integration
try:
    import dspy
    from src.infra.dspy_ollama_integration import OllamaLM, configure_dspy_with_ollama
    logger.info("Successfully imported DSPy and OllamaLM")
except ImportError as e:
    logger.error(f"Failed to import required modules: {e}")
    logger.error("Please install DSPy with: pip install dspy")
    sys.exit(1)

# Define a simple signature for testing
class SimpleQA(dspy.Signature):
    """Answer a question concisely."""
    question = dspy.InputField(desc="The question to answer")
    answer = dspy.OutputField(desc="A concise answer to the question")

def simple_metric(example, prediction, trace=None):
    """A trivial metric that always returns 1.0 (success)."""
    logger.info(f"Evaluating prediction: {prediction.answer}")
    return 1.0

def test_ollama_direct_call():
    """Test direct calling of OllamaLM."""
    logger.info("Testing direct OllamaLM call...")
    
    # Create OllamaLM instance
    ollama_lm = OllamaLM(model_name="mistral:latest", temperature=0.1)
    
    # Try a simple direct call
    try:
        start_time = time.time()
        response = ollama_lm("What is the capital of France?")
        elapsed = time.time() - start_time
        
        logger.info(f"Direct call completed in {elapsed:.2f}s")
        logger.info(f"Response: {response}")
        
        if response and isinstance(response, list) and len(response) > 0:
            logger.info("✓ Direct call test PASSED")
            return True
        else:
            logger.error("✗ Direct call test FAILED: Empty or invalid response")
            return False
    
    except Exception as e:
        logger.error(f"✗ Direct call test FAILED with error: {e}")
        return False

def test_dspy_predict():
    """Test DSPy Predict module with OllamaLM."""
    logger.info("Testing DSPy Predict with OllamaLM...")
    
    # Configure DSPy to use OllamaLM
    ollama_lm = configure_dspy_with_ollama(model_name="mistral:latest", temperature=0.1)
    if not ollama_lm:
        logger.error("Failed to configure DSPy with OllamaLM")
        return False
    
    # Create a simple DSPy Predict module
    simple_qa = dspy.Predict(SimpleQA)
    
    # Try a prediction
    try:
        start_time = time.time()
        prediction = simple_qa(question="What is the capital of France?")
        elapsed = time.time() - start_time
        
        logger.info(f"DSPy Predict completed in {elapsed:.2f}s")
        logger.info(f"Prediction answer: {prediction.answer}")
        
        if prediction and hasattr(prediction, 'answer') and prediction.answer:
            logger.info("✓ DSPy Predict test PASSED")
            return True
        else:
            logger.error("✗ DSPy Predict test FAILED: No valid prediction")
            return False
    
    except Exception as e:
        logger.error(f"✗ DSPy Predict test FAILED with error: {e}")
        return False

def test_dspy_optimizer():
    """Test DSPy optimizer (BootstrapFewShot) with OllamaLM."""
    logger.info("Testing DSPy optimizer with OllamaLM...")
    
    # Configure DSPy to use OllamaLM
    ollama_lm = configure_dspy_with_ollama(model_name="mistral:latest", temperature=0.1)
    if not ollama_lm:
        logger.error("Failed to configure DSPy with OllamaLM")
        return False
    
    # Create a simple DSPy module
    simple_qa = dspy.Predict(SimpleQA)
    
    # Create a tiny training set
    trainset = [
        dspy.Example(
            question="What is the capital of France?",
            answer="Paris"
        ).with_inputs("question"),
        dspy.Example(
            question="What is the capital of Japan?",
            answer="Tokyo"
        ).with_inputs("question")
    ]
    
    # Create an optimizer
    optimizer = dspy.teleprompt.BootstrapFewShot(
        metric=simple_metric,
        max_bootstrapped_demos=1,
        max_labeled_demos=2
    )
    
    # Try to compile the module
    try:
        logger.info("Starting DSPy optimization...")
        start_time = time.time()
        
        # Log optimization details
        logger.debug(f"Optimizer type: {type(optimizer).__name__}")
        logger.debug(f"Student module type: {type(simple_qa).__name__}")
        logger.debug(f"Trainset size: {len(trainset)}")
        logger.debug(f"DSPy LM settings: {dspy.settings.lm}")
        
        # Compile the module
        optimized_qa = optimizer.compile(
            student=simple_qa,
            trainset=trainset
        )
        
        elapsed = time.time() - start_time
        logger.info(f"DSPy optimization completed in {elapsed:.2f}s")
        
        # Verify the optimized module works
        test_question = "What is the capital of Spain?"
        prediction = optimized_qa(question=test_question)
        
        logger.info(f"Optimized module prediction for '{test_question}': {prediction.answer}")
        
        logger.info("✓ DSPy optimizer test PASSED")
        return True
    
    except Exception as e:
        logger.error(f"✗ DSPy optimizer test FAILED with error: {e}")
        import traceback
        logger.error(traceback.format_exc())
        return False
    
def run_all_tests():
    """Run all tests and report results."""
    logger.info("=" * 50)
    logger.info("STARTING DSPY-OLLAMA INTEGRATION TESTS")
    logger.info("=" * 50)
    
    test_results = {
        "direct_call": test_ollama_direct_call(),
        "dspy_predict": test_dspy_predict(),
        "dspy_optimizer": test_dspy_optimizer()
    }
    
    logger.info("=" * 50)
    logger.info("TEST SUMMARY")
    logger.info("=" * 50)
    
    all_passed = True
    for test_name, result in test_results.items():
        status = "PASSED" if result else "FAILED"
        logger.info(f"{test_name}: {status}")
        if not result:
            all_passed = False
    
    logger.info("=" * 50)
    if all_passed:
        logger.info("ALL TESTS PASSED! DSPy-Ollama integration is working correctly.")
    else:
        logger.info("SOME TESTS FAILED. Check the logs for details.")
    logger.info("=" * 50)
    
    return all_passed

if __name__ == "__main__":
    run_all_tests() 