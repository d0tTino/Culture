#!/usr/bin/env python
"""
Simplified implementation of role adherence for immediate testing
without DSPy dependencies.
"""

import json
import logging
import sys
from pathlib import Path
from typing import Dict, Any, List, Tuple

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger("simplified_role_adherence")

# Add the project root to Python path for importing project modules
sys.path.append(str(Path(__file__).parent.parent))

# Sample role definitions (simplified for testing)
ROLES = {
    "Innovator": "An agent focused on generating creative and novel ideas, thinking outside the box, and introducing unconventional perspectives.",
    "Analyzer": "An agent focused on critical evaluation, risk assessment, examining flaws in ideas, and considering practical constraints.",
    "Facilitator": "An agent focused on promoting collaboration, summarizing discussions, finding consensus, and ensuring productive communication."
}

def verify_role_adherence(thought: str, role: str) -> Dict[str, Any]:
    """
    Verify if a generated thought adheres to the specified role.
    Returns metrics about role adherence.
    """
    thought_lower = thought.lower()
    role_lower = role.lower()
    
    # Define role-specific keywords
    role_keywords = {
        "innovator": ["new", "novel", "creative", "idea", "innovative", "unconventional", "possibility"],
        "analyzer": ["evaluate", "analysis", "risk", "consider", "examine", "critical", "flaw", "practical"],
        "facilitator": ["summarize", "consensus", "collaboration", "discussion", "synthesis", "clarify", "communication"]
    }
    
    # Count keyword matches
    keywords = role_keywords.get(role_lower, [])
    matches = sum(1 for keyword in keywords if keyword in thought_lower)
    
    # Check for role phrase
    role_phrase = f"as a {role_lower}"
    alt_role_phrase = f"as an {role_lower}"
    has_role_phrase = role_phrase in thought_lower or alt_role_phrase in thought_lower
    
    # Calculate score
    score = min(1.0, matches / 4)  # Normalize to 0-1 range
    if has_role_phrase:
        score = min(1.0, score + 0.3)  # Boost score if explicit role mention exists
    
    return {
        "role": role,
        "score": score,
        "passes_threshold": score >= 0.5,
        "keyword_matches": matches,
        "has_role_phrase": has_role_phrase
    }

def generate_prompt_for_role(role: str, context: str) -> str:
    """
    Generate a prompt optimized for role adherence.
    """
    role_description = ROLES.get(role, f"{role}: Contribute effectively based on your role.")
    
    prompt = f"""You are acting as an agent with the specific role of {role}.

ROLE: {role}
ROLE DESCRIPTION: {role_description}

CONTEXT:
{context}

IMPORTANT INSTRUCTION FOR THOUGHT GENERATION:
Your internal thought must strongly reflect your role as a {role}.
Begin your thought with 'As a {role},' and ensure your entire thought process clearly demonstrates thinking consistent with your role description.

Generate a thought process that reflects your role:"""
    
    return prompt

def simulate_generated_thought(role: str, context: str) -> str:
    """
    Simulate a thought that might be generated for testing purposes.
    In a real implementation, this would call an LLM.
    """
    thoughts = {
        "Innovator": {
            "project": "As an Innovator, I see an opportunity to create a completely new approach to this project. What if we used machine learning to automate the testing process entirely? This would be a novel way to address the resource constraints while potentially improving accuracy.",
            "meeting": "As an Innovator, I'm thinking we could shake up this meeting format by introducing digital whiteboards where everyone contributes ideas simultaneously rather than the traditional turn-taking approach. This could unleash creative thinking in ways we haven't explored."
        },
        "Analyzer": {
            "project": "As an Analyzer, I need to examine the potential risks of this approach. The timeline seems optimistic given the current resource allocation. We should consider what would happen if the initial phase takes longer than expected and how that would affect subsequent milestones.",
            "meeting": "As an Analyzer, I'm evaluating the effectiveness of this meeting format. While the agenda covers the main topics, we might be missing critical discussions about the technical debt that's accumulating in the backend. This could cause problems in our next release cycle."
        },
        "Facilitator": {
            "project": "As a Facilitator, I notice there are diverse perspectives being shared about this project approach. I should help synthesize these viewpoints into a cohesive plan that addresses both innovation opportunities and practical concerns, ensuring everyone's input is valued.",
            "meeting": "As a Facilitator, I see an opportunity to improve our collaboration by summarizing the key points discussed so far and identifying where we have consensus versus where we need further discussion. This will help us make better use of our remaining meeting time."
        }
    }
    
    # Return a thought based on role and context, or a generic one if not found
    if role in thoughts and context in thoughts[role]:
        return thoughts[role][context]
    
    return f"As a {role}, I should consider how to approach this {context} based on my role responsibilities and expertise."

def test_verification_with_samples() -> List[Dict[str, Any]]:
    """
    Test the verification mechanism with a few sample thoughts.
    """
    test_cases = []
    
    # Test each role with on-topic and off-topic thoughts
    for role in ROLES:
        # Test with aligned thought
        for context in ["project", "meeting"]:
            thought = simulate_generated_thought(role, context)
            metrics = verify_role_adherence(thought, role)
            test_cases.append({
                "role": role,
                "context": context,
                "thought": thought,
                "metrics": metrics
            })
        
        # Test with misaligned thought (using a different role's thought)
        other_roles = [r for r in ROLES if r != role]
        if other_roles:
            other_role = other_roles[0]
            misaligned_thought = simulate_generated_thought(other_role, "project")
            metrics = verify_role_adherence(misaligned_thought, role)
            test_cases.append({
                "role": role,
                "context": "project (misaligned)",
                "thought": misaligned_thought,
                "metrics": metrics,
                "note": f"Using {other_role}'s thought for {role} role"
            })
    
    return test_cases

def main():
    """
    Main function to run the tests and generate a report.
    """
    logger.info("Running role adherence verification tests")
    
    test_results = test_verification_with_samples()
    
    # Save the results
    with open(Path(__file__).parent / "simplified_role_adherence_results.json", "w") as f:
        json.dump(test_results, f, indent=2)
    
    # Generate a summary report
    total_tests = len(test_results)
    aligned_tests = sum(1 for test in test_results if "misaligned" not in test.get("context", ""))
    misaligned_tests = total_tests - aligned_tests
    
    passing_aligned = sum(1 for test in test_results 
                         if "misaligned" not in test.get("context", "") and test["metrics"]["passes_threshold"])
    failing_misaligned = sum(1 for test in test_results
                            if "misaligned" in test.get("context", "") and not test["metrics"]["passes_threshold"])
    
    aligned_accuracy = (passing_aligned / aligned_tests) * 100 if aligned_tests > 0 else 0
    misaligned_accuracy = (failing_misaligned / misaligned_tests) * 100 if misaligned_tests > 0 else 0
    
    # Create and save the report
    report = f"""# Simplified Role Adherence Test Report

## Summary

- **Total Test Cases**: {total_tests}
- **Aligned Role Tests**: {aligned_tests}
- **Misaligned Role Tests**: {misaligned_tests}
- **Aligned Tests Passing**: {passing_aligned}/{aligned_tests} ({aligned_accuracy:.1f}%)
- **Misaligned Tests Correctly Identified**: {failing_misaligned}/{misaligned_tests} ({misaligned_accuracy:.1f}%)

## Test Case Details

| Role | Context | Adherence Score | Passes? | Keywords Found | Has Role Phrase |
|------|---------|-----------------|---------|----------------|-----------------|
"""

    for test in test_results:
        metrics = test["metrics"]
        # Using ASCII compatible symbols instead of Unicode
        passes_symbol = "YES" if metrics["passes_threshold"] else "NO"
        role_phrase_symbol = "YES" if metrics["has_role_phrase"] else "NO"
        report += f"| {test['role']} | {test['context']} | {metrics['score']:.2f} | {passes_symbol} | {metrics['keyword_matches']} | {role_phrase_symbol} |\n"
    
    report += f"""
## Sample Prompt Template

```
{generate_prompt_for_role("Innovator", "Example context goes here")}
```

## Conclusion

This simple verification approach demonstrates {aligned_accuracy:.1f}% accuracy in identifying role-adherent thoughts and {misaligned_accuracy:.1f}% accuracy in flagging misaligned thoughts. The prompt structure and verification metrics provide a solid foundation for implementing role adherence in the main codebase.

## Next Steps

1. Integrate this approach directly into the agent turn generation process
2. Collect metrics on role adherence in production simulation runs
3. Refine the keyword lists and scoring system based on real-world results
"""
    
    with open(Path(__file__).parent / "simplified_role_adherence_report.md", "w") as f:
        f.write(report)
    
    logger.info(f"Report saved to {Path(__file__).parent / 'simplified_role_adherence_report.md'}")

if __name__ == "__main__":
    main() 