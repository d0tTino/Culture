# Role-Specific DSPy Summarizers

This module implements role-optimized DSPy-based summarizers that generate summaries tailored to specific agent roles.

## Overview

The role-specific summarizers enhance the agent's summarization capabilities by generating summaries that better reflect the agent's perspective, thought patterns, and communication style based on their role. This is accomplished by:

1. Creating distinct example sets for each role (Innovator, Analyzer, Facilitator)
2. Training role-specific models using DSPy's BootstrapFewShot optimization
3. Providing a unified interface that selects the appropriate model based on the agent's role

## Implementation Details

### Role-Specific Example Files

Each role has dedicated example files for both L1 (immediate) and L2 (consolidated) summaries:

- **Innovator**: Examples emphasize creativity, novel connections, pattern recognition, and unconventional thinking
- **Analyzer**: Examples focus on systematic analysis, data-driven insights, methodical problem-solving, and evidence-based reasoning
- **Facilitator**: Examples highlight group dynamics management, consensus building, conflict resolution, and structured communication

### Optimization Scripts

Two optimization scripts are provided:

1. `optimize_role_l1_summarizers.py`: Optimizes L1 summarizers for all three roles
2. `optimize_role_l2_summarizers.py`: Optimizes L2 summarizers for all three roles

These scripts use DSPy's BootstrapFewShot algorithm to find optimal few-shot examples for each role and save the optimized models.

### Role-Specific Summary Generator

The `RoleSpecificSummaryGenerator` class provides a unified interface for generating summaries based on agent role:

```python
from src.agents.dspy_programs.role_specific_summary_generator import RoleSpecificSummaryGenerator

# Create the generator
generator = RoleSpecificSummaryGenerator()

# Generate an L1 summary for an Innovator
innovator_summary = generator.generate_l1_summary(
    agent_role="Innovator",
    recent_events="...",
    current_mood="excited"
)

# Generate an L2 summary for an Analyzer
analyzer_summary = generator.generate_l2_summary(
    agent_role="Analyzer",
    l1_summaries_context="...",
    overall_mood_trend="methodical and increasingly confident",
    agent_goals="Optimize system performance through data analysis"
)
```

The generator automatically selects the appropriate role-specific model when available or falls back to the default summarizer.

## Role Characteristics

### Innovator

- **Thinking Style**: Divergent, associative, pattern-connecting
- **Focus Areas**: Novel possibilities, creative solutions, unexpected connections
- **Language Patterns**: Metaphorical, possibility-oriented, emphasizes breakthroughs and insights
- **Perspective**: Looks beyond conventional boundaries to find new approaches

### Analyzer

- **Thinking Style**: Systematic, logical, evidence-based
- **Focus Areas**: Data patterns, causal relationships, empirical testing
- **Language Patterns**: Precise, quantitative, methodical, includes specific metrics and evidence
- **Perspective**: Examines problems thoroughly through structured analysis and evaluation

### Facilitator

- **Thinking Style**: Integrative, process-oriented, relationship-focused
- **Focus Areas**: Group dynamics, consensus building, decision processes
- **Language Patterns**: Inclusive, balanced, emphasizes shared understanding and collaborative outcomes
- **Perspective**: Considers multiple viewpoints and helps navigate complex social interactions

## Testing

Use the `test_role_specific_summarizers.py` script to test the role-specific summarizer implementation. This script generates L1 and L2 summaries for each role and displays the results.

## Extending to Additional Roles

To extend this framework to additional roles:

1. Create new role-specific example files
2. Add the role to `SUPPORTED_ROLES` in `RoleSpecificSummaryGenerator`
3. Update the optimization scripts to include the new role
4. Run the optimization scripts to generate compiled models for the new role 