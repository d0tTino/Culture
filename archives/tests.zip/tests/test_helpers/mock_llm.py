"""
Mock helpers for LLM-dependent tests.
"""
import socket
from unittest.mock import MagicMock

def is_ollama_running():
    """Check if Ollama server is running by attempting to connect to localhost:11434"""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(0.1)  # Short timeout for quick check
        s.connect(("localhost", 11434))
        s.close()
        return True
    except (socket.error, socket.timeout):
        return False

class MockLLMResponse:
    """Mock response for LLMClient"""
    def __init__(self, content="This is a mock response"):
        self.content = content
        self.structured_output = {"thought": "Mock thought", "message_content": "Mock message"}

def create_mock_llm_client():
    """Create a mock LLMClient"""
    mock_client = MagicMock()
    mock_client.generate_response.return_value = MockLLMResponse()
    mock_client.generate_structured_output.return_value = MockLLMResponse().structured_output
    return mock_client 