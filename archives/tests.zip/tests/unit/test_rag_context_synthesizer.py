"""
Unit tests for the RAGContextSynthesizer class.
"""

import unittest
import sys
import os
from unittest.mock import patch, MagicMock
from typing import Dict, Any

# Add project root to the path so we can import modules
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))

# Import the module to test
from src.agents.dspy_programs.rag_context_synthesizer import RAGContextSynthesizer, RAGSynthesis

class TestRAGContextSynthesizer(unittest.TestCase):
    """Test cases for the RAGContextSynthesizer class."""
    
    @patch('src.infra.llm_client.generate_response')
    def setUp(self, mock_generate_response):
        """Set up for each test case"""
        self.mock_llm_client = MagicMock()
        # Configure the global mock passed by @patch
        mock_generate_response.return_value = "Mocked LLM synthesis result."

        self.synthesizer = RAGContextSynthesizer(llm_client=self.mock_llm_client)
    
    @patch('src.agents.dspy_programs.rag_context_synthesizer.configure_dspy_with_ollama')
    @patch('src.agents.dspy_programs.rag_context_synthesizer.os.path.exists')
    def test_initialization_without_compiled_program(self, mock_exists, mock_configure):
        """Test that the class initializes correctly when no compiled program exists."""
        # Set up mock
        mock_exists.return_value = False
        
        # Initialize the synthesizer
        synthesizer = RAGContextSynthesizer()
        
        # Verify configure_dspy_with_ollama was called
        mock_configure.assert_called_once()
        
        # Check that we have a dspy_program attribute that's a dspy.Module
        self.assertIsNotNone(synthesizer.dspy_program)
    
    @patch('src.agents.dspy_programs.rag_context_synthesizer.configure_dspy_with_ollama')
    @patch('src.agents.dspy_programs.rag_context_synthesizer.os.path.exists')
    @patch('dspy.Predict.load')
    def test_initialization_with_compiled_program(self, mock_load, mock_exists, mock_configure):
        """Test that the class initializes correctly when a compiled program exists."""
        # Set up mocks
        mock_exists.return_value = True
        
        # Initialize with a dummy path
        test_path = "dummy/path.json"
        synthesizer = RAGContextSynthesizer(compiled_program_path=test_path)
        
        # Verify mocks were called
        mock_exists.assert_called_with(test_path)
        # Check that load was called with the path
        mock_load.assert_called_once()
        
        # Verify synthesizer has a dspy_program
        self.assertIsNotNone(synthesizer.dspy_program)
    
    def test_clean_output_with_bracket_prefix(self):
        """Test that _clean_output removes the ']]' prefix from text."""
        synthesizer = RAGContextSynthesizer()
        
        # Test cases with the bracket prefix
        test_cases = [
            "]] This is a test answer.",
            "]]This is a test answer.",
            "]]] This is a test answer with extra bracket.",
            "]]  This is a test answer with extra spaces.",
            " ]] This is a test answer with leading space."
        ]
        
        expected_result = "This is a test answer."
        
        for test_input in test_cases:
            cleaned = synthesizer._clean_output(test_input)
            self.assertTrue(cleaned.startswith("This"))
            self.assertFalse("]]" in cleaned)
    
    def test_clean_output_without_bracket_prefix(self):
        """Test that _clean_output handles text without the prefix correctly."""
        synthesizer = RAGContextSynthesizer()
        
        # Test cases without the bracket prefix
        test_cases = [
            "This is a clean test answer.",
            "  This is a test answer with leading spaces.",
            "This is a test answer with a ]] in the middle.",
            ""  # Empty string
        ]
        
        for test_input in test_cases:
            cleaned = synthesizer._clean_output(test_input)
            self.assertEqual(cleaned, test_input.strip())
    
    @patch('src.agents.dspy_programs.rag_context_synthesizer.configure_dspy_with_ollama')
    def test_synthesize_success(self, mock_configure):
        """Test the synthesize method with a successful prediction."""
        # Create a synthesizer with a mocked dspy_program
        synthesizer = RAGContextSynthesizer()
        
        # Create a mock prediction with the known artifact
        mock_prediction = MagicMock()
        mock_prediction.synthesized_answer = "]] This is a synthesized answer."
        
        # Replace the real dspy_program with our mock
        synthesizer.dspy_program = MagicMock()
        synthesizer.dspy_program.return_value = mock_prediction
        
        # Call synthesize
        result = synthesizer.synthesize(
            context="Test context",
            question="Test question"
        )
        
        # Check the result
        self.assertEqual(result, "This is a synthesized answer.")
        
        # Verify the dspy_program was called with the right parameters
        synthesizer.dspy_program.assert_called_with(
            context="Test context",
            question="Test question"
        )
    
    @patch('src.agents.dspy_programs.rag_context_synthesizer.configure_dspy_with_ollama')
    def test_synthesize_error_handling(self, mock_configure):
        """Test that synthesize handles errors gracefully."""
        # Create a synthesizer with a dspy_program that raises an exception
        synthesizer = RAGContextSynthesizer()
        
        # Make the dspy_program raise an exception when called
        synthesizer.dspy_program = MagicMock()
        synthesizer.dspy_program.side_effect = Exception("Test error")
        
        # Call synthesize
        result = synthesizer.synthesize(
            context="Test context",
            question="Test question"
        )
        
        # Check that we get an empty string as the fallback
        self.assertEqual(result, "")

if __name__ == '__main__':
    unittest.main() 