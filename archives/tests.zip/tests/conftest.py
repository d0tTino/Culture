"""
Pytest fixtures for use across test files.
"""
import pytest
from unittest.mock import patch
from tests.test_helpers.mock_llm import create_mock_llm_client, is_ollama_running
from src.infra.llm_mock_helper import patch_ollama_functions

# Mark for tests requiring Ollama
require_ollama = pytest.mark.skipif(
    not is_ollama_running(),
    reason="Ollama server is not running on localhost:11434"
)

@pytest.fixture
def mock_llm_client():
    """Fixture to provide a mocked LLMClient"""
    with patch("src.infra.llm_client.LLMClient") as MockLLMClient:
        mock_client = create_mock_llm_client()
        MockLLMClient.return_value = mock_client
        yield MockLLMClient

@pytest.fixture(autouse=True)
def mock_ollama_by_default(request, monkeypatch):
    """
    Automatically mock Ollama functions unless the test is explicitly marked with require_ollama.
    
    This prevents 404 errors when Ollama is not running.
    """
    # Skip mocking if test is marked with require_ollama
    if request.node.get_closest_marker('require_ollama'):
        # If marked with require_ollama but server isn't running, the test will be skipped
        # by the require_ollama mark, so we don't need to do anything here
        return
    
    # If test is not explicitly requiring Ollama, mock all Ollama functions
    patch_ollama_functions(monkeypatch) 