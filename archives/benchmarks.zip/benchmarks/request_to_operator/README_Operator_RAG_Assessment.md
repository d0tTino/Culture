# RAG Assessment Instructions for Operators

This guide explains how to perform qualitative assessment of RAG (Retrieval-Augmented Generation) responses to finalize the MUS threshold tuning report.

## Overview

You'll be evaluating agent responses to standard queries across different memory pruning configurations. Your assessment will determine which memory pruning configuration offers the best balance between memory efficiency and information retrieval quality.

## Step-by-Step Process

### 1. Generate the Assessment Template

First, run the script to create the assessment template CSV:

```bash
cd benchmarks/request_to_operator
python generate_rag_csv_template.py
```

This will generate a file called `rag_assessment_template.csv` in the same directory.

### 2. Review and Score Agent Responses

Open `rag_assessment_template.csv` in a spreadsheet application (Excel, Google Sheets, etc.)

For each row in the spreadsheet:
1. Locate the response file indicated in the `response_file_path` column
   - These will be located relative to the `request_to_operator` directory
   - Each file contains an agent's response to the query listed in that row
2. Evaluate the response according to the criteria below
3. Fill in the `qualitative_score` column with an integer from 1-5
4. Add any notes or observations in the `assessment_notes` column

#### Scoring Criteria (1-5 scale)

|Score|Level|Description|
|---|---|---|
|5|Excellent|The response is completely relevant, accurate, coherent, and comprehensive|
|4|Good|The response is mostly relevant, accurate, and coherent with minor omissions|
|3|Adequate|The response is somewhat relevant and accurate but lacks some details or coherence|
|2|Poor|The response has significant gaps, inaccuracies, or irrelevant information|
|1|Very Poor|The response is mostly irrelevant, inaccurate, or fails to answer the query|

When evaluating responses, consider these four dimensions:
- **Relevance**: How well the response addresses the specific query
- **Coherence**: How well-organized and logical the response is
- **Completeness**: Whether all key information is included 
- **Accuracy**: Whether the provided information is factually correct

### 3. Integrate Your Assessments

After completing all assessments in the CSV file, run the integration script:

```bash
python integrate_rag_scores.py
```

This will:
- Process your assessment scores
- Update the JSON assessment files for each scenario
- Calculate average scores and metrics

### 4. Finalize the Report Data

Run the finalization script to update the comparative data:

```bash
python finalize_report_data.py
```

This will:
- Update the main comparative data file with your assessment scores
- Recalculate overall scenario rankings
- Generate an updated RAG scores plot

## File Locations

- Response files: `../tuning_results/[scenario]/rag_assessment/agent_X_response_Y.txt`
- Template CSV: `./rag_assessment_template.csv`
- Updated plot: `../tuning_results/rag_scores.png`

## Common Questions

**Q: How long should the assessment take?**  
A: There are 156 responses to evaluate (13 scenarios × 4 agents × 3 queries). Each response should take about 1-2 minutes to assess, for a total of 3-5 hours. You can split this work over multiple sessions.

**Q: What if a response seems to be missing information?**  
A: This is likely the result of aggressive memory pruning in that scenario. Score it according to the quality of what's provided - this is exactly what we're trying to measure.

**Q: What's the most important aspect to evaluate?**  
A: Focus primarily on whether the response contains the key information needed to answer the query correctly. Coherence and presentation are secondary to information completeness and accuracy.

## Next Steps

After you've completed these steps, notify the team that the assessment is complete. We'll use this data to generate the final MUS threshold tuning report and implement the optimal memory pruning configuration.

Thank you for your contribution to improving memory management in our system! 