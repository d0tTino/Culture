#!/usr/bin/env python3
"""
Script to finalize report data by updating the comparative_data.json file
with qualitative RAG scores from individual scenario assessment files.
Optionally updates or prepares data for plot regeneration.
"""

import json
import os
import sys
from pathlib import Path
import matplotlib.pyplot as plt
import numpy as np

def load_assessment_files(tuning_results_dir):
    """
    Load RAG assessment data from all scenario directories.
    
    Args:
        tuning_results_dir: Path to the tuning_results directory
    
    Returns:
        Dictionary mapping scenario names to their assessment metrics
    """
    assessment_data = {}
    
    # List all scenario directories
    for item in tuning_results_dir.iterdir():
        if item.is_dir():
            scenario = item.name
            assessment_file = item / "rag_assessment" / f"{scenario}_rag_assessment.json"
            
            if assessment_file.exists():
                try:
                    with open(assessment_file, 'r') as f:
                        data = json.load(f)
                        
                    if "overall_metrics" in data:
                        assessment_data[scenario] = data["overall_metrics"]
                        print(f"Loaded assessment data for {scenario}: avg_score={data['overall_metrics']['avg_score']}")
                    else:
                        print(f"Warning: Missing overall_metrics in assessment file for {scenario}")
                except Exception as e:
                    print(f"Error loading assessment file for {scenario}: {e}")
    
    return assessment_data

def update_comparative_data(comparative_file, assessment_data):
    """
    Update the comparative_data.json file with RAG assessment scores.
    
    Args:
        comparative_file: Path to comparative_data.json
        assessment_data: Dictionary of assessment metrics by scenario
        
    Returns:
        Updated comparative data dictionary
    """
    try:
        # Load existing comparative data
        with open(comparative_file, 'r') as f:
            comparative_data = json.load(f)
        
        # Update with assessment data
        scenarios_updated = 0
        for scenario, metrics in assessment_data.items():
            if scenario in comparative_data.get("scenarios", {}):
                # Update RAG assessment fields
                comparative_data["scenarios"][scenario]["rag_assessment"] = metrics
                
                # Calculate overall score as average of memory_efficiency_score and normalized RAG score
                memory_eff = comparative_data["scenarios"][scenario].get("memory_efficiency_score", 0)
                
                # Only update if the RAG score is available and not zero
                if metrics.get("avg_score", 0) > 0:
                    # Normalize RAG score from 1-5 to 0-1 range and average with memory efficiency
                    rag_score_normalized = (metrics["avg_score"] - 1) / 4  # Maps 1-5 to 0-1
                    overall_score = (memory_eff + rag_score_normalized) / 2
                    comparative_data["scenarios"][scenario]["overall_score"] = round(overall_score, 3)
                    scenarios_updated += 1
        
        # Write updated comparative data
        with open(comparative_file, 'w') as f:
            json.dump(comparative_data, f, indent=2)
            
        print(f"Updated comparative data for {scenarios_updated} scenarios.")
        return comparative_data
    
    except Exception as e:
        print(f"Error updating comparative data: {e}")
        return None

def prepare_rag_score_plot_data(comparative_data):
    """
    Prepare data for RAG score plot.
    
    Args:
        comparative_data: Dictionary containing the updated comparative data
        
    Returns:
        Dictionary with plot data
    """
    scenarios = []
    rag_scores = []
    memory_scores = []
    overall_scores = []
    
    # Get data for each scenario
    for scenario_id, scenario_data in comparative_data.get("scenarios", {}).items():
        # Skip scenarios with no RAG assessment
        if scenario_data.get("rag_assessment", {}).get("avg_score", 0) <= 0:
            continue
            
        scenarios.append(scenario_id)
        rag_scores.append(scenario_data["rag_assessment"]["avg_score"])
        memory_scores.append(scenario_data["memory_efficiency_score"])
        overall_scores.append(scenario_data["overall_score"])
    
    return {
        "scenarios": scenarios,
        "rag_scores": rag_scores,
        "memory_scores": memory_scores,
        "overall_scores": overall_scores
    }

def generate_rag_scores_plot(plot_data, output_path):
    """
    Generate RAG scores plot.
    
    Args:
        plot_data: Dictionary with plot data
        output_path: Output path for the plot image
    """
    try:
        # Sort data by overall score
        indices = np.argsort(plot_data["overall_scores"])[::-1]  # Descending
        
        scenarios = [plot_data["scenarios"][i] for i in indices]
        rag_scores = [plot_data["rag_scores"][i] for i in indices]
        memory_scores = [plot_data["memory_scores"][i] for i in indices]
        overall_scores = [plot_data["overall_scores"][i] for i in indices]
        
        # Create figure
        plt.figure(figsize=(12, 8))
        
        # Plot as grouped bar chart
        x = np.arange(len(scenarios))
        width = 0.25
        
        plt.bar(x - width, memory_scores, width, label='Memory Efficiency', color='steelblue')
        plt.bar(x, [s/5 for s in rag_scores], width, label='RAG Score (normalized)', color='darkorange')
        plt.bar(x + width, overall_scores, width, label='Overall Score', color='forestgreen')
        
        # Customize plot
        plt.xlabel('Scenario')
        plt.ylabel('Score')
        plt.title('Memory Efficiency vs. RAG Performance by Scenario')
        plt.xticks(x, scenarios, rotation=45, ha='right')
        plt.legend()
        plt.grid(axis='y', linestyle='--', alpha=0.7)
        plt.tight_layout()
        
        # Save plot
        plt.savefig(output_path)
        print(f"Generated RAG scores plot: {output_path}")
        
    except Exception as e:
        print(f"Error generating RAG scores plot: {e}")

def main():
    # Paths
    script_dir = Path(__file__).parent
    tuning_results_dir = script_dir.parent / "tuning_results"
    comparative_file = tuning_results_dir / "comparative_data.json"
    rag_plot_file = tuning_results_dir / "rag_scores.png"
    
    if not tuning_results_dir.exists() or not comparative_file.exists():
        print(f"Error: Required files not found. Please check if the path exists: {tuning_results_dir}")
        sys.exit(1)
    
    # Load assessment data from all scenarios
    print("Loading RAG assessment data from scenario directories...")
    assessment_data = load_assessment_files(tuning_results_dir)
    
    if not assessment_data:
        print("No assessment data found. Please run integrate_rag_scores.py first.")
        sys.exit(1)
    
    # Update comparative data
    print(f"Updating comparative data file: {comparative_file}")
    updated_data = update_comparative_data(comparative_file, assessment_data)
    
    if updated_data:
        # Prepare plot data
        plot_data = prepare_rag_score_plot_data(updated_data)
        
        # Generate plot if we have enough data
        if len(plot_data["scenarios"]) > 0:
            generate_rag_scores_plot(plot_data, rag_plot_file)
            print("\nSuccess! All data has been updated with qualitative RAG assessments.")
            print("The next step is to have Claude generate the final version of the report.")
        else:
            print("\nNot enough data available to generate the RAG scores plot.")
            print("Please ensure RAG assessments have been completed for all scenarios.")
    
    print("\nProcess complete. You can now proceed with finalizing the report.")

if __name__ == "__main__":
    main() 